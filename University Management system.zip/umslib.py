import tkinter as tk
from tkinter import messagebox
from tkinter import *
import PIL.Image, PIL.ImageTk

# Teachers data file
with open("Teachers.txt", "w+") as teachers_ptr:
    if teachers_ptr:
        print("Teachers data file opened successfully")
        teachers_ptr.write("""Dr.Fareed,PHD-Circuits,3410155,LRH,CA\nDr.Samia,PHD-Mathematics,3410166,Lahore,MVC\nDr.Usman,PHD-Physics,3410177,GRW,EM\nDr.Salman,PHD-EE,3410221,LHR,EC\nDr.Asim,PHD-Mathematics,3410232,LHR,LA\nDr.Ahsan,PHD-CS,3410243,LHR,ITC\nDr.Saadia,PHD-AM,3410287,KHI,FM\nDr.Anjum,PHD-DS,3410298,ISB, PDE\nDr.Kashif,PHD-VC,3410309,FSD,FD\n""")
        teachers_ptr.seek(0)
        tec_info = teachers_ptr.readlines()
        teachers_info = []
        sub = []
        for j in tec_info:
            t = j.strip().split(",")
            teachers_info.append(t)
        for l in range(len(teachers_info)):
            for k in range(len(teachers_info[l])):
                if k == 4:
                    sub.append(teachers_info[l][4])

# department data files
# dep 1: Computer Engineering
with open("CE department.txt", "w+") as CE_ptr:
    if CE_ptr:
        print("CE department data file opened successfully")
        CE_ptr.write("""Department of Computer Engineering\nCE01,CE02,CE03\nGhazala,Wasay,Ali\nHamayo,Kaleem,Ahmed\nCA MVC EM,CA MVC EM,CA MVC EM\n3410122,3410133,3410144\n84,79,91\nDay scholar,Hostelite,Hostelite\nDr.Fareed,Dr.Samia,Dr.Usman\nPHD-Circuits,PHD-Mathematics,PHD-Physics\n3410155,3410166,3410177\nLRH,LHR,GRW\nCA,MVC,EM""")
        CE_ptr.seek(0)
        CE_info = CE_ptr.readlines()
        for i in range(len(CE_info)):
            d = CE_info[i].strip().split(",")
            if i == 0:
                dep_CE = d
            if i == 1:
                stu_roll_ce = d
            if i == 2:
                stu_name_ce = d
            if i == 3:
                stu_fn_ce = d
            if i == 4:
                stu_c_ce = d
            if i == 5:
                stu_CNIC_ce = d
            if i == 6:
                stu_aggregate_ce = d
            if i == 7:
                stu_status_ce = d
            if i == 8:
                tec_name_ce = d
            if i == 9:
                tec_degree_ce = d
            if i == 10:
                tec_CNIC_ce = d
            if i == 11:
                tec_City_ce = d
            if i == 12:
                tec_sub_ce = d


# dep 2: Electrical Engineering
with open("EE department.txt", "w+") as EE_ptr:
    if EE_ptr:
        print("EE department data file opened successfully")
        EE_ptr.write("""Department of Electrical Engineering\nEE01,EE02,EE03\nSaboor,Ahmad,Sajad\nAli,Hassan,Khan\nEC LA ITC,EC LA ITC,EC LA ITC\n3410188,3410199,3410210\n88,82,78\nHostelite,Day Scholar,Day Scholar\nDr.Salman,Dr.Asim,Dr.Ahsan\nPHD-EE,PHD-Mathematics,PHD-CS\n3410221,3410232,3410243\nLHR,LHR,LHR\nEC,LA,ITC""")
        EE_ptr.seek(0)
        EE_info = EE_ptr.readlines()
        for i in range(len(EE_info)):
            p = EE_info[i].strip().split(",")
            if i == 0:
                dep_EE = p
            if i == 1:
                stu_roll_ee = p
            if i == 2:
                stu_name_ee = p
            if i == 3:
                stu_fn_ee = p
            if i == 4:
                stu_c_ee = p
            if i == 5:
                stu_CNIC_ee = p
            if i == 6:
                stu_aggregate_ee = p
            if i == 7:
                stu_status_ee = p
            if i == 8:
                tec_name_ee = p
            if i == 9:
                tec_degree_ee = p
            if i == 10:
                tec_CNIC_ee = p
            if i == 11:
                tec_City_ee = p
            if i == 12:
                tec_sub_ee = p


# dep 3: Mathematics
with open("MTH department.txt", "w+") as MTH_ptr:
    if MTH_ptr:
        print("MTH department data file opened successfully")
        MTH_ptr.write("""Department of Mathematics\nMTH01,MTH02,MTH03\nRabia,Asjad,Shafaq\nBaig,Haseeb,Zahra\nFM PDE FD,FM PDE FD,FM PDE FD\n3410254,3410265,3410276\n80,75,86\nHostelite,Day Scholar,Hostelite\nDr.Saadia,Dr.Anjum,Dr.Kashif\nPHD-AM,PHD-DS,PHD-VC\n3410287,3410298,3410309\nKHI,ISB,FSD\nFM,PDE,FD""")
        MTH_ptr.seek(0)
        MTH_info = MTH_ptr.readlines()
        for i in range(len(MTH_info)):
            g = MTH_info[i].strip().split(",")
            if i == 0:
                dep_MTH = g
            if i == 1:
                stu_roll_mth = g
            if i == 2:
                stu_name_mth = g
            if i == 3:
                stu_fn_mth = g
            if i == 4:
                stu_c_mth = g
            if i == 5:
                stu_CNIC_mth = g
            if i == 6:
                stu_aggregate_mth = g
            if i == 7:
                stu_status_mth = g
            if i == 8:
                tec_name_mth = g
            if i == 9:
                tec_degree_mth = g
            if i == 10:
                tec_CNIC_mth = g
            if i == 11:
                tec_City_mth = g
            if i == 12:
                tec_sub_mth = g


# all books file
with open("books.txt", "w+") as book_ptr:
    if book_ptr:
        print("Books file opened successfully")
        book_ptr.write("""R1C1,R1C2,R1C3,R1C4,R1C5\nPython Crash Course,The Great Gatsby,To Kill a Mockingbird,1984,Pride and Prejudice\nEric Matthes,F. Scott Fitzgerald,Harper Lee,George Orwell,Jane Austen\n1st Edition,2nd Edition,1st Edition,3rd Edition,2nd Edition\n""")
    book_ptr.seek(0)
    books_info = book_ptr.readlines()
    for i in range(len(books_info)):
        g = books_info[i].strip().split(",")
        if i == 0:
            book_location = g
        if i == 1:
            book_name = g
        if i == 2:
            book_author = g
        if i == 3:
            book_edition = g

# borrowed books file
with open("Borrowed books.txt", "w+") as brw_ptr:
    if brw_ptr:
        print("Borrowed books file opened successfully")
        brw_ptr.write("""CE01,EE02,MTH01,CE02,EE01\nThe Chronicles of Narnia,The Alchemist,Harry Potter and the Sorcerer's Stone,To Kill a Kingdom,The Lord of the Rings\nC.S. Lewis,Paulo Coelho,J.K. Rowling,Alexandra Christo,J.R.R. Tolkien\n1st Edition,2nd Edition,1st Edition,3rd Edition,2nd Edition\n""")
    brw_ptr.seek(0)
    brw_info = brw_ptr.readlines()
    for i in range(len(brw_info)):
        g = brw_info[i].strip().split(",")
        if i == 0:
            brw_id = g
        if i == 1:
            brw_name = g
        if i == 2:
            brw_author = g
        if i == 3:
            brw_edition = g


# attendance calculator
def attendance_cal(att, days):
    global att_count, attendance
    attendance = att.strip().split()
    att_count = 0
    for v in range(2, len(attendance)):
        if attendance[v] == "P" or "p":
            att_count += 1
    e = (att_count / days) * 100
    if e >= 75:
        print(f"{ask33} you are eligible to sit in the exam")
    else:
        print(f"{ask33} you are not eligible to sit in the exam")


# to display profile of CE student
def CE_profile_displayer(ask3ab):
    global stu_name_ce, stu_fn_ce, stu_c_ce, stu_CNIC_ce, stu_status_ce, stu_roll_ce, stu_aggregate_ce
    if ask3ab in stu_roll_ce:
        i_ndex = stu_roll_ce.index(ask3ab)
        messagebox.showinfo("Student of CE", f"Name = {stu_name_ce[i_ndex]}\n Father name = {stu_fn_ce[i_ndex]}\n CNIC = {stu_CNIC_ce[i_ndex]}\n Reg no = {stu_roll_ce[i_ndex]}\n Registered Courses = {stu_c_ce[i_ndex]}\n Aggregate = {stu_aggregate_ce[i_ndex]}\n Status = {stu_status_ce[i_ndex]}")




# to view profile of EE student
def EE_profile_displayer(ask3ab):
    global stu_name_ee, stu_fn_ee, stu_c_ee, stu_CNIC_ee, stu_status_ee, stu_roll_ee, stu_aggregate_ee
    if ask3ab in stu_roll_ee:
        i_ndex = stu_roll_ee.index(ask3ab)
        messagebox.showinfo("Student of EE", f"Name = {stu_name_ee[i_ndex]}\n Father name = {stu_fn_ee[i_ndex]}\n CNIC = {stu_CNIC_ee[i_ndex]}\n Reg no = {stu_roll_ee[i_ndex]}\n Registered Courses = {stu_c_ee[i_ndex]}\n Aggregate = {stu_aggregate_ee[i_ndex]}\n Status = {stu_status_ee[i_ndex]}")



# to view profile of MTH student
def MTH_profile_displayer(ask3ab):
    global stu_name_mth, stu_fn_mth, stu_c_mth, stu_CNIC_mth, stu_status_mth, stu_roll_mth, stu_aggregate_mth
    if ask3ab in stu_roll_mth:
        i_ndex = stu_roll_mth.index(ask3ab)
        messagebox.showinfo("Student of MTH", f"Name = {stu_name_mth[i_ndex]}\n Father name = {stu_fn_mth[i_ndex]}\n CNIC = {stu_CNIC_mth[i_ndex]}\n Reg no = {stu_roll_mth[i_ndex]}\n Registered Courses = {stu_c_mth[i_ndex]}\n Aggregate = {stu_aggregate_mth[i_ndex]}\n Status = {stu_status_mth[i_ndex]}")



# to display profile of CE tec
def CE_tec_profile_displayer(ask2bb):
    global tec_name_ce, tec_sub_ce, tec_City_ce, tec_CNIC_ce, tec_degree_ce
    if ask2bb in tec_name_ce:
        i_ndex = tec_name_ce.index(ask2bb)
        messagebox.showinfo("Teacher of CE", f"Name = {tec_name_ce[i_ndex]}\nDegree = {tec_degree_ce[i_ndex]}\nCNIC = {tec_CNIC_ce[i_ndex]}\nCity = {tec_City_ce[i_ndex]}\nSubject= {tec_sub_ce[i_ndex]}")

# to display profile of EE tec
def EE_tec_profile_displayer(ask2bb):
    global tec_name_ee, tec_sub_ee, tec_City_ee, tec_CNIC_ee, tec_degree_ee
    if ask2bb in tec_name_ee:
        i_ndex = tec_name_ee.index(ask2bb)
        messagebox.showinfo("Teacher of EE", f"Name = {tec_name_ce[i_ndex]}\nDegree = {tec_degree_ce[i_ndex]}\nCNIC = {tec_CNIC_ce[i_ndex]}\nCity = {tec_City_ce[i_ndex]}\nSubject= {tec_sub_ce[i_ndex]}")

# to diaplay profile of MTH tec
def MTH_tec_profile_displayer(ask2bb):
    global tec_name_mth, tec_sub_mth, tec_City_mth, tec_CNIC_mth, tec_degree_mth
    if ask2bb in tec_name_mth:
        i_ndex = tec_name_mth.index(ask2bb)
        messagebox.showinfo("Teacher of MTH", f"Name = {tec_name_ce[i_ndex]}\nDegree = {tec_degree_ce[i_ndex]}\nCNIC = {tec_CNIC_ce[i_ndex]}\nCity = {tec_City_ce[i_ndex]}\nSubject= {tec_sub_ce[i_ndex]}")

# challan displayer according to aggregate of CE
def CE_challan_agg(challan_of):
    if int(stu_aggregate_ce[challan_of]) >= 85:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_ce[challan_of]}\nFather name = {stu_fn_ce[challan_of]}\nCNIC = {stu_CNIC_ce[challan_of]}\nRoll no = {stu_roll_ce[challan_of]}\nCategory = A1\nAcademic Fee = 55,767\n")
    elif int(stu_aggregate_ce[challan_of]) >= 75:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_ce[challan_of]}\nFather name = {stu_fn_ce[challan_of]}\nCNIC = {stu_CNIC_ce[challan_of]}\nRoll no = {stu_roll_ce[challan_of]}\nCategory = A2\nAcademic Fee = 1 lac\n")
    elif int(stu_aggregate_ce[challan_of]) >= 65:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_ce[challan_of]}\nFather name = {stu_fn_ce[challan_of]}\nCNIC = {stu_CNIC_ce[challan_of]}\nRoll no = {stu_roll_ce[challan_of]}\nCategory = Full paid\nAcademic Fee = 1.5 lac\n")

# challan displayer according to aggregate of CE
def CE_challan_agg_H(challan_of):
    if int(stu_aggregate_ce[challan_of]) >= 85:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_ce[challan_of]}\nFather name = {stu_fn_ce[challan_of]}\nCNIC = {stu_CNIC_ce[challan_of]}\nRoll no = {stu_roll_ce[challan_of]}\nCategory = A1\nAcademic Fee = 55,767\nHostel Dues = 5,529\n")
    elif int(stu_aggregate_ce[challan_of]) >= 75:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_ce[challan_of]}\nFather name = {stu_fn_ce[challan_of]}\nCNIC = {stu_CNIC_ce[challan_of]}\nRoll no = {stu_roll_ce[challan_of]}\nCategory = A2\nAcademic Fee = 1 lac\nHostel Dues = 5,529\n")
    elif int(stu_aggregate_ce[challan_of]) >= 65:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_ce[challan_of]}\nFather name = {stu_fn_ce[challan_of]}\nCNIC = {stu_CNIC_ce[challan_of]}\nRoll no = {stu_roll_ce[challan_of]}\nCategory = Full paid\nAcademic Fee = 1.5 lac\nHostel Dues = 5,529\n")

# challan displayer according to aggregate of EE
def EE_challan_agg(challan_of):
    if int(stu_aggregate_ee[challan_of]) >= 85:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_ee[challan_of]}\nFather name = {stu_fn_ee[challan_of]}\nCNIC = {stu_CNIC_ee[challan_of]}\nRoll no = {stu_roll_ee[challan_of]}\nCategory = A1\nAcademic Fee = 55,767\n")
    elif int(stu_aggregate_ee[challan_of]) >= 75:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_ee[challan_of]}\nFather name = {stu_fn_ee[challan_of]}\nCNIC = {stu_CNIC_ee[challan_of]}\nRoll no = {stu_roll_ee[challan_of]}\nCategory = A2\nAcademic Fee = 1 lac\n")
    elif int(stu_aggregate_ee[challan_of]) >= 65:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_ee[challan_of]}\nFather name = {stu_fn_ee[challan_of]}\nCNIC = {stu_CNIC_ee[challan_of]}\nRoll no = {stu_roll_ee[challan_of]}\nCategory = Full paid\nAcademic Fee = 1.5 lac\n")

# challan displayer according to aggregate of EE
def EE_challan_agg_H(challan_of):
    if int(stu_aggregate_ee[challan_of]) >= 85:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_ee[challan_of]}\nFather name = {stu_fn_ee[challan_of]}\nCNIC = {stu_CNIC_ee[challan_of]}\nRoll no = {stu_roll_ee[challan_of]}\nCategory = A1\nAcademic Fee = 55,767\nHostel Dues = 5,529\n")
    elif int(stu_aggregate_ee[challan_of]) >= 75:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_ee[challan_of]}\nFather name = {stu_fn_ee[challan_of]}\nCNIC = {stu_CNIC_ee[challan_of]}\nRoll no = {stu_roll_ee[challan_of]}\nCategory = A2\nAcademic Fee = 1 lac\nHostel Dues = 5,529\n")
    elif int(stu_aggregate_ee[challan_of]) >= 65:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_ee[challan_of]}\nFather name = {stu_fn_ee[challan_of]}\nCNIC = {stu_CNIC_ee[challan_of]}\nRoll no = {stu_roll_ee[challan_of]}\nCategory = Full paid\nAcademic Fee = 1.5 lac\nHostel Dues = 5,529\n")

# challan displayer according to aggregate of MTH
def MTH_challan_agg(challan_of):
    if int(stu_aggregate_mth[challan_of]) >= 85:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_mth[challan_of]}\nFather name = {stu_fn_mth[challan_of]}\nCNIC = {stu_CNIC_mth[challan_of]}\nRoll no = {stu_roll_mth[challan_of]}\nCategory = A1\nAcademic Fee = 55,767\n")
    elif int(stu_aggregate_mth[challan_of]) >= 75:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_mth[challan_of]}\nFather name = {stu_fn_mth[challan_of]}\nCNIC = {stu_CNIC_mth[challan_of]}\nRoll no = {stu_roll_mth[challan_of]}\nCategory = A2\nAcademic Fee = 1 lac\n")
    elif int(stu_aggregate_mth[challan_of]) >= 65:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_mth[challan_of]}\nFather name = {stu_fn_mth[challan_of]}\nCNIC = {stu_CNIC_mth[challan_of]}\nRoll no = {stu_roll_mth[challan_of]}\nCategory = Full paid\nAcademic Fee = 1.5 lac\n")

# challan displayer according to aggregate of MTH
def MTH_challan_agg_H(challan_of):
    if int(stu_aggregate_mth[challan_of]) >= 85:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_mth[challan_of]}\nFather name = {stu_fn_mth[challan_of]}\nCNIC = {stu_CNIC_mth[challan_of]}\nRoll no = {stu_roll_mth[challan_of]}\nCategory = A1\nAcademic Fee = 55,767\nHostel Dues = 5,529\n")
    elif int(stu_aggregate_mth[challan_of]) >= 75:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_mth[challan_of]}\nFather name = {stu_fn_mth[challan_of]}\nCNIC = {stu_CNIC_mth[challan_of]}\nRoll no = {stu_roll_mth[challan_of]}\nCategory = A2\nAcademic Fee = 1 lac\nHostel Dues = 5,529\n")
    elif int(stu_aggregate_mth[challan_of]) >= 65:
        messagebox.showinfo("Challan Form", f"Name = {stu_name_mth[challan_of]}\nFather name = {stu_fn_mth[challan_of]}\nCNIC = {stu_CNIC_mth[challan_of]}\nRoll no = {stu_roll_mth[challan_of]}\nCategory = Full paid\nAcademic Fee = 1.5 lac\nHostel Dues = 5,529\n")

# change CE data
def change_CE(address):
    global stu_name_ce, stu_fn_ce, stu_c_ce, stu_CNIC_ce, stu_status_ce, stu_roll_ce, stu_aggregate_ce, tec_name_ce, tec_degree_ce, tec_CNIC_ce, tec_City_ce, tec_sub_ce, dep_CE
    with open("CE department.txt", "w+") as CE_ptr:
        CE_info = []
        CE_info.append(dep_CE)
        CE_info.append(stu_roll_ce)
        CE_info.append(stu_name_ce)
        CE_info.append(stu_fn_ce)
        CE_info.append(stu_c_ce)
        CE_info.append(stu_CNIC_ce)
        CE_info.append(stu_status_ce)
        CE_info.append(tec_name_ce)
        CE_info.append(tec_degree_ce)
        CE_info.append(tec_CNIC_ce)
        CE_info.append(tec_City_ce)
        CE_info.append(tec_sub_ce)
        if CE_ptr:
            print("Ce department file opened successfully")
            CE_ptr.truncate()
            for to_write in CE_info:
                CE_ptr.write(",".join(to_write) + "\n")
        messagebox.showinfo(address, "Changing is done successfully")

# change EE data
def change_ee(address):
    with open("EE department.txt", "w+") as EE_ptr:
        EE_info = []
        EE_info.append(dep_EE)
        EE_info.append(stu_roll_ee)
        EE_info.append(stu_name_ee)
        EE_info.append(stu_fn_ee)
        EE_info.append(stu_c_ee)
        EE_info.append(stu_CNIC_ee)
        EE_info.append(stu_status_ee)
        EE_info.append(tec_name_ee)
        EE_info.append(tec_degree_ee)
        EE_info.append(tec_CNIC_ee)
        EE_info.append(tec_City_ee)
        EE_info.append(tec_sub_ee)
        if EE_ptr:
            print("EE department file opened successfully")
            EE_ptr.truncate()
            for to_write in EE_info:
                EE_ptr.write(",".join(to_write) + "\n")
        messagebox.showinfo(address, "Changing is done successfully")

# change mth data
def change_mth(address):
    with open("MTH department.txt", "w+") as MTH_ptr:
        MTH_info = []
        MTH_info.append(dep_MTH)
        MTH_info.append(stu_roll_mth)
        MTH_info.append(stu_name_mth)
        MTH_info.append(stu_fn_mth)
        MTH_info.append(stu_c_mth)
        MTH_info.append(stu_CNIC_mth)
        MTH_info.append(stu_status_mth)
        MTH_info.append(tec_name_mth)
        MTH_info.append(tec_degree_mth)
        MTH_info.append(tec_CNIC_mth)
        MTH_info.append(tec_City_mth)
        MTH_info.append(tec_sub_mth)
        if MTH_ptr:
            print("MTH department file opened successfully")
            MTH_ptr.truncate()
            for to_write in MTH_info:
                MTH_ptr.write(",".join(to_write) + "\n")
        messagebox.showinfo(address, "Changing is done successfully")

# change sub of tec from tec file
def change_tec_sub(xxx, yyy, address):
    with open("Teachers.txt", "w+") as teachers_ptr:
        if teachers_ptr:
            print("Teachers file opened successfully")
            teachers_ptr.truncate()
            for tch in teachers_info:
                if xxx in tch:
                    tch[4] = yyy
                    break
            for to_write in teachers_info:
                teachers_ptr.write(",".join(to_write) + "\n")
            messagebox.showinfo(address, "Teacher subject has been change")

# change file of tec
def change_tec_file():
    with open("Teachers.txt", "w+") as teachers_ptr:
        if teachers_ptr:
            print("Teachers data file opened successfully")
            teachers_ptr.seek(0)
            teachers_ptr.truncate()
            for tec in tec_info:
                teachers_ptr.write("".join(tec))



# to display courses
def add_course(dis, address):
    if dis == "Computer Engineering":
        Label(address, text=f"List of compulsory courses\n{stu_c_ce[0]}", width=70).pack()
    if dis == "Electrical Engineering":
        Label(address, text=f"List of compulsory courses\n{stu_c_ee[0]}", width=70).pack()
    if dis == "Mathematics":
        Label(address, text=f"List of compulsory courses\n{stu_c_mth[0]}", width=70).pack()

# books displayer
def change_library_file():
    global books_info, book_edition, book_name, book_author, book_location
    with open("books.txt","w+") as book_ptr:
        if book_ptr:
            print("Books file opened successfully")
            books_info = []
            books_info.append(book_location)
            books_info.append(book_name)
            books_info.append(book_author)
            books_info.append(book_edition)
            book_ptr.truncate()
            for book in books_info:
                book_ptr.write(",".join(book) + "\n")

# change borrowed book file
def change_brw_file():
    global brw_info, brw_edition, brw_name, brw_author, brw_id
    with open("Borrowed books.txt","w+") as brw_ptr:
        if brw_ptr:
            print("Borrowed books file opened successfully")
            brw_info = []
            brw_info.append(brw_id)
            brw_info.append(brw_name)
            brw_info.append(brw_author)
            brw_info.append(brw_edition)
            brw_ptr.truncate()
            for brw in brw_info:
                brw_ptr.write(",".join(brw) + "\n")

# CE attendance file
with open("CE Attendance.txt", "w+") as CE_att_ptr:
    if CE_att_ptr:
        CE_att_ptr.write("""Ghazala, Wasay, Ali\nCE01, CE02, CE03\n""")
        print("CE attendance file opened successfully")
        CE_att_ptr.seek(0)
        ce_att_info = CE_att_ptr.readlines()
        for att in range(len(ce_att_info)):
            g = ce_att_info[att].strip().split()
            if att == 0:
                att_ce_name = g
            if att == 1:
                att_ce_roll = g

# EE attendance file
with open("EE Attendance.txt", "w+") as EE_att_ptr:
    if EE_att_ptr:
        EE_att_ptr.write("""Saboor, Ahmad, Sajad\nEE01, EE02, EE03\n""")
        print("EE attendance file opened successfully")
        EE_att_ptr.seek(0)
        ee_att_info = EE_att_ptr.readlines()
        for att_e in range(len(ee_att_info)):
            h = ee_att_info[att_e].strip().split()
            if att_e == 0:
                att_ee_name = h
            if att_e == 1:
                att_ee_roll = h

# MTH attendance file
with open("MTH Attendance.txt", "w+") as MTH_att_ptr:
    if MTH_att_ptr:
        MTH_att_ptr.write("""Rabia, Asjad, Shafaq\nMTH01, MTH02, MTH03\n""")
        print("MTH attendance file opened successfully")
        MTH_att_ptr.seek(0)
        mth_att_info = MTH_att_ptr.readlines()
        for att_m in range(len(mth_att_info)):
            h = mth_att_info[att_m].strip().split()
            if att_m == 0:
                att_mth_name = h
            if att_m == 1:
                att_mth_roll = h

# CE GPA file
with open("CE GPA.txt", "w+") as CE_gpa_ptr:
    if CE_gpa_ptr:
        CE_gpa_ptr.write("""Ghazala, Wasay, Ali\nCE01, CE02, CE03\n""")
        print("CE GPA file opened successfully")
        CE_gpa_ptr.seek(0)
        ce_gpa_info = CE_gpa_ptr.readlines()
        for gpa in range(len(ce_gpa_info)):
            g = ce_gpa_info[gpa].strip().split()
            if gpa == 0:
                gpa_ce_name = g
            if gpa == 1:
                gpa_ce_roll = g

# EE GPA File
with open("EE GPA.txt", "w+") as EE_gpa_ptr:
    if EE_gpa_ptr:
        EE_gpa_ptr.write("""Saboor, Ahmad, Sajad\nEE01, EE02, EE03\n""")
        print("EE GPA file opened successfully")
        EE_gpa_ptr.seek(0)
        ee_gpa_info = EE_gpa_ptr.readlines()
        for gpa_e in range(len(ee_gpa_info)):
            h = ee_gpa_info[gpa_e].strip().split()
            if gpa_e == 0:
                gpa_ee_name = h
            if gpa_e == 1:
                gpa_ee_roll = h

# MTH GPA File
with open("MTH Attendance.txt", "w+") as MTH_gpa_ptr:
    if MTH_gpa_ptr:
        MTH_gpa_ptr.write("""Rabia, Asjad, Shafaq\nMTH01, MTH02, MTH03\n""")
        print("MTH attendance file opened successfully")
        MTH_gpa_ptr.seek(0)
        mth_gpa_info = MTH_gpa_ptr.readlines()
        for gpa_m in range(len(mth_gpa_info)):
            h = mth_gpa_info[att_m].strip().split()
            if gpa_m == 0:
                gpa_mth_name = h
            if gpa_m == 1:
                gpa_mth_roll = h


# hostel rooms
with open("alloted-room.txt", "w+") as allot_ptr:
    if allot_ptr:
        print("File created successfully")
        allot_ptr.write("Room1,Room2,Room3,Room4,Room5,Room6\nEE01,CE02,MTH03\nSaboor,Wasay,Shafaq\n3410133,3410188,3410276")
    allot_ptr.seek(0)
    rooms_info = allot_ptr.readlines()

    for i in range(len(rooms_info)):
        temps = rooms_info[i].strip().split(",")
        if i == 0:
            rooms = temps
        if i == 1:
            st_roll_no = temps
        if i == 2:
            alloted_students = temps
            temp = len(alloted_students)
            alloted_rooms = rooms[:temp]
            empty_rooms = rooms[temp:]
        if i == 3:
            st_cnic = temps

# change hostel data
def hostel_info_update():
    rooms = alloted_rooms + empty_rooms
    for i in range(len(rooms_info)):
        if i == 0:
            rooms_info[i] = ",".join(rooms)
        if i == 1:
            rooms_info[i] = ",".join(st_roll_no)
        if i == 2:
            rooms_info[i] = ",".join(alloted_students)
        if i == 3:
            rooms_info[i] = ",".join(st_cnic)

    with open("alloted-room.txt", "w+") as allot_ptr:
        for i in range(len(rooms_info)):
            allot_ptr.write(rooms_info[i])
            allot_ptr.write("\n")


# CE attendance file
with open("CE Attendance.txt", "w+") as CE_att_ptr:
    if CE_att_ptr:
        CE_att_ptr.write("""Ghazala, Wasay, Ali\nCE01, CE02, CE03\n""")
        print("CE attendance file opened successfully")
        CE_att_ptr.seek(0)
        ce_att_info = CE_att_ptr.readlines()
        for att in range(len(ce_att_info)):
            g = ce_att_info[att].strip().split()
            if att == 0:
                att_ce_name = g
            if att == 1:
                att_ce_roll = g

# EE attendance file
with open("EE Attendance.txt", "w+") as EE_att_ptr:
    if EE_att_ptr:
        EE_att_ptr.write("""Saboor, Ahmad, Sajad\nEE01, EE02, EE03\n""")
        print("EE attendance file opened successfully")
        EE_att_ptr.seek(0)
        ee_att_info = EE_att_ptr.readlines()
        for att_e in range(len(ee_att_info)):
            h = ee_att_info[att_e].strip().split()
            if att_e == 0:
                att_ee_name = h
            if att_e == 1:
                att_ee_roll = h

# MTH attendance file
with open("MTH Attendance.txt", "w+") as MTH_att_ptr:
    if MTH_att_ptr:
        MTH_att_ptr.write("""Rabia, Asjad, Shafaq\nMTH01, MTH02, MTH03\n""")
        print("MTH attendance file opened successfully")
        MTH_att_ptr.seek(0)
        mth_att_info = MTH_att_ptr.readlines()
        for att_m in range(len(mth_att_info)):
            h = mth_att_info[att_m].strip().split()
            if att_m == 0:
                att_mth_name = h
            if att_m == 1:
                att_mth_roll = h

# CE GPA file
with open("CE GPA.txt", "w+") as CE_gpa_ptr:
    if CE_gpa_ptr:
        CE_gpa_ptr.write("""Ghazala, Wasay, Ali\nCE01, CE02, CE03\n""")
        print("CE GPA file opened successfully")
        CE_gpa_ptr.seek(0)
        ce_gpa_info = CE_gpa_ptr.readlines()
        for gpa in range(len(ce_gpa_info)):
            g = ce_gpa_info[gpa].strip().split()
            if gpa == 0:
                gpa_ce_name = g
            if gpa == 1:
                gpa_ce_roll = g

# EE GPA File
with open("EE GPA.txt", "w+") as EE_gpa_ptr:
    if EE_gpa_ptr:
        EE_gpa_ptr.write("""Saboor, Ahmad, Sajad\nEE01, EE02, EE03\n""")
        print("EE GPA file opened successfully")
        EE_gpa_ptr.seek(0)
        ee_gpa_info = EE_gpa_ptr.readlines()
        for gpa_e in range(len(ee_gpa_info)):
            h = ee_gpa_info[gpa_e].strip().split()
            if gpa_e == 0:
                gpa_ee_name = h
            if gpa_e == 1:
                gpa_ee_roll = h

# MTH GPA File
with open("MTH Attendance.txt", "w+") as MTH_gpa_ptr:
    if MTH_gpa_ptr:
        MTH_gpa_ptr.write("""Rabia, Asjad, Shafaq\nMTH01, MTH02, MTH03\n""")
        print("MTH attendance file opened successfully")
        MTH_gpa_ptr.seek(0)
        mth_gpa_info = MTH_gpa_ptr.readlines()
        for gpa_m in range(len(mth_gpa_info)):
            h = mth_gpa_info[att_m].strip().split()
            if gpa_m == 0:
                gpa_mth_name = h
            if gpa_m == 1:
                gpa_mth_roll = h

