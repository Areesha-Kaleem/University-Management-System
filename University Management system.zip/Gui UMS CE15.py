import tkinter as tk
from tkinter import messagebox
from tkinter import *
import PIL.Image, PIL.ImageTk
import umslib


# Create the main window
window = tk.Tk()
window.geometry(f"{window.winfo_screenwidth()}x{window.winfo_screenheight()}")
bg_image = PIL.Image.open("20230218_155711.jpg")
bg_image = bg_image.resize((window.winfo_screenwidth(), window.winfo_screenheight()))
background_image = PIL.ImageTk.PhotoImage(bg_image)

# Create a label widget to display the background image
background_label = tk.Label(window, image=background_image)
background_label.place(x=0, y=0, relwidth=1, relheight=1)
window.title("University Of Engineering And Technology")

icon_image = PIL.Image.open("University_of_Engineering_and_Technology_Lahore_logo.png")
window_icon = PIL.ImageTk.PhotoImage(icon_image)
window.iconphoto(True, window_icon)


def open_profile(profile):
    profile_window = tk.Toplevel(window)
    profile_window.title(f"{profile} Profile")
    profile_window.geometry("500x500")

    if profile == "Admin":
        window.withdraw()
        A_works = ["Library Manager", "Hostel Manager", "Departmental Manager"]
        for A_work in A_works:
            A_work_button = tk.Button(profile_window, text=A_work, font=("Arial", 12), width=30,command=lambda p=A_work: open_admin_options(p))
            A_work_button.pack(pady=10)

        def open_admin_options(work):
            admin_options_window = tk.Toplevel(profile_window)
            admin_options_window.title(f"{work}")
            admin_options_window.geometry("500x500")

            # bgimage = PIL.Image.open("WhatsApp Image 2023-07-18 at 5.06.45 PM.jpeg")
            # bgimage = bgimage.resize((500, 500))
            # bgimage = PIL.ImageTk.PhotoImage(bgimage)
            # bglabel = tk.Label(admin_options_window, image=bgimage)
            # bglabel.place(x=0, y=0, relwidth=1, relheight=1)


            if work == "Library Manager":
                L_works = ["Find Book", "Add book", "Remove book", "Borrow Book", "Edit Book Info","Return Book"]
                for L_work in L_works:
                    L_work_button = tk.Button(admin_options_window, text=L_work, font=("Arial", 12), width=30,command=lambda p=L_work: open_LM_options(p))
                    L_work_button.pack(pady=10)

                def open_LM_options(lmw):
                    admin_options_window.withdraw()

                    def book_finder():
                        book_find = find_book_entry.get()
                        if book_find:
                            if book_find in umslib.book_name:
                                book_index = umslib.book_name.index(book_find)
                                messagebox.showinfo("Book Location",f"Location of {book_find} is {umslib.book_location[book_index]}")
                                find_book_window.withdraw()
                            else:
                                messagebox.showerror("Error", "Book Not Found.")
                        else:
                            messagebox.showerror("Error", "Please Enter Book Name.")

                    def book_adder():
                        bookname = add_book_entry1.get()
                        bookauthor = add_book_entry2.get()
                        bookedition = add_book_entry3.get()
                        if bookname and bookauthor and bookedition:
                            if bookname not in umslib.book_name:
                                v = len(umslib.book_location) - 1
                                vv = len(umslib.book_location[v]) - 1
                                new_book_location = int(umslib.book_location[v][vv]) + 1
                                new_bk_loc = "R1C" + str(new_book_location)
                                umslib.book_name.append(bookname)
                                umslib.book_author.append(bookauthor)
                                umslib.book_edition.append(bookedition)
                                umslib.book_location.append(new_bk_loc)
                                umslib.change_library_file()
                                messagebox.showinfo("Add Book", f"Book Added Successfully.")
                                add_book_window.withdraw()
                            else:
                                messagebox.showerror("Error", "This Book Already Exists.")
                        else:
                            messagebox.showerror("Error", "Please Fill Complete Information")

                    def book_remover():
                        bookremove = remove_book_entry.get()
                        if bookremove == "":
                            messagebox.showerror("Error", "Please Fill Complete Information")
                        else:
                            if bookremove in umslib.book_name:
                                rb_index = umslib.book_name.index(bookremove)
                                umslib.book_name.pop(rb_index)
                                umslib.book_author.pop(rb_index)
                                umslib.book_edition.pop(rb_index)
                                umslib.book_location.pop(rb_index)
                                umslib.change_library_file()
                                messagebox.showinfo("Remove Book","Book Removed Successfully.")
                                remove_book_window.withdraw()
                            else:
                                messagebox.showerror("Error","No such book exists")

                    def book_borrower():
                        bookborrow = borrow_book_entry.get()
                        studentid = borrow_student_id_entry.get()
                        if bookborrow or studentid:
                            if bookborrow in umslib.book_name:
                                bb_index = umslib.book_name.index(bookborrow)
                                umslib.brw_name.append(umslib.book_name[bb_index])
                                umslib.brw_author.append(umslib.book_author[bb_index])
                                umslib.brw_edition.append(umslib.book_edition[bb_index])
                                umslib.brw_id.append(studentid)
                                umslib.book_name.pop(bb_index)
                                umslib.book_author.pop(bb_index)
                                umslib.book_edition.pop(bb_index)
                                umslib.book_location.pop(bb_index)
                                umslib.change_library_file()
                                umslib.change_brw_file()
                                messagebox.showinfo("Borrow Book", f"Issued Book: {bookborrow}\nIssued to: {studentid}")
                                borrow_book_window.withdraw()
                            else:
                                messagebox.showerror("Error", "No such book exists")
                        else:
                            messagebox.showerror("Error", "Please Fill Complete Information")

                    def show_borrowed_books():
                        borrowed_books = "\n".join([f"Book no {to_dis + 1}\nBook name = {umslib.brw_name[to_dis]}\nBook author = {umslib.brw_author[to_dis]}\nBook edition = {umslib.brw_edition[to_dis]}\nBorrowed by = {umslib.brw_id[to_dis]}" for to_dis in range(len(umslib.brw_name))])
                        messagebox.showinfo("Borrowed Books",f"{borrowed_books}")

                    def book_editor():
                        bookedit = edit_book_entry.get()
                        bookeditauthor = edit_book_entry1.get()
                        bookeditedition = edit_book_entry2.get()
                        bookeditlocation = edit_book_entry3.get()
                        if bookedit == "" or bookeditauthor == "" or bookeditedition == "" or bookeditlocation == "":
                            messagebox.showerror("Error", "Please Fill Complete Information")
                        else:
                            if bookedit in umslib.book_name:
                                be_index = umslib.book_name.index(bookedit)
                                if bookeditlocation:
                                    umslib.book_location[be_index] = bookeditlocation
                                if bookeditauthor:
                                    umslib.book_author[be_index] = bookeditauthor
                                if bookeditedition:
                                    umslib.book_edition[be_index] = bookeditedition
                                umslib.change_library_file()
                                messagebox.showinfo("Edit Book", "Book Edited Successfully.")
                                edit_book_window.withdraw()
                            else:
                                messagebox.showerror("Error", "No such book exists")

                    def book_returner():
                        bookreturn = return_book_entry.get()
                        if bookreturn == "":
                            messagebox.showerror("Error", "Please Fill Complete Information")
                        else:
                            if bookreturn in umslib.brw_name:
                                br_index = umslib.brw_name.index(bookreturn)
                                umslib.book_name.append(umslib.brw_name[br_index])
                                umslib.book_author.append(umslib.brw_author[br_index])
                                umslib.book_edition.append(umslib.brw_edition[br_index])
                                umslib.book_location.append("R1C1")
                                umslib.brw_name.pop(br_index)
                                umslib.brw_author.pop(br_index)
                                umslib.brw_edition.pop(br_index)
                                umslib.brw_id.pop(br_index)
                                umslib.change_library_file()
                                umslib.change_brw_file()
                                messagebox.showinfo("Return Book", "Book Returned Successfully.")
                                return_book_window.withdraw()
                            else:
                                messagebox.showerror("Error", "No such book exists")

                    def show_all_books():
                        all_books = "\n".join([f"Book no {to_dis + 1}\nBook name = {umslib.book_name[to_dis]}\nBook author = {umslib.book_author[to_dis]}\nBook edition = {umslib.book_edition[to_dis]}\nBook location = {umslib.book_location[to_dis]}" for to_dis in range(len(umslib.book_name))])
                        messagebox.showinfo("All Books",f"{all_books}")

                    if lmw == "Find Book":
                        find_book_window = tk.Toplevel(admin_options_window)
                        find_book_window.title("Find Book")
                        find_book_window.geometry("500x500")
                        find_book_window.resizable(True, True)
                        find_book_window.configure(bg="white")
                        find_book_window.iconphoto(True, window_icon)
                        find_book_label = tk.Label(find_book_window, text="Enter Book Name", font=("Arial", 12), bg="white")
                        find_book_label.pack(pady=10)
                        find_book_entry = tk.Entry(find_book_window, font=("Arial", 12), borderwidth=3)
                        find_book_entry.pack(pady=10)
                        find_book_button = tk.Button(find_book_window, text="Find", font=("Arial", 12), width=30, command= book_finder)
                        find_book_button.pack(pady=10)

                    elif lmw == "Add book":
                        add_book_window = tk.Toplevel(admin_options_window)
                        add_book_window.title("Add Book")
                        add_book_window.geometry("500x500")
                        add_book_window.resizable(False, False)
                        add_book_window.configure(bg="white")
                        add_book_window.iconphoto(True, window_icon)
                        add_book_name = tk.Label(add_book_window, text="Enter Book Name", font=("Arial", 12), bg="white")
                        add_book_name.pack(pady=10)
                        add_book_entry1 = tk.Entry(add_book_window, font=("Arial", 12), borderwidth=3)
                        add_book_entry1.pack(pady=10)
                        add_book_author = tk.Label(add_book_window, text="Enter Author Name", font=("Arial", 12), bg="white")
                        add_book_author.pack(pady=10)
                        add_book_entry2 = tk.Entry(add_book_window, font=("Arial", 12), borderwidth=3)
                        add_book_entry2.pack(pady=10)
                        add_book_edition = tk.Label(add_book_window, text="Enter Book Edition", font=("Arial", 12), bg="white")
                        add_book_edition.pack(pady=10)
                        add_book_entry3 = tk.Entry(add_book_window, font=("Arial", 12), borderwidth=3)
                        add_book_entry3.pack(pady=10)
                        add_book_button = tk.Button(add_book_window, text="Add", font=("Arial", 12), width=30, command=book_adder)
                        add_book_button.pack(pady=10)

                    elif lmw == "Remove book":
                        remove_book_window = tk.Toplevel(admin_options_window)
                        remove_book_window.title("Remove Book")
                        remove_book_window.geometry("500x500")
                        remove_book_window.resizable(False, False)
                        remove_book_window.configure(bg="grey")
                        remove_book_window.iconphoto(True, window_icon)
                        remove_book_label = tk.Label(remove_book_window, text="Enter Book Name", font=("Arial", 12), bg="white")
                        remove_book_label.pack(pady=10)
                        remove_book_entry = tk.Entry(remove_book_window, font=("Arial", 12), borderwidth=3)
                        remove_book_entry.pack(pady=10)
                        remove_book_button = tk.Button(remove_book_window, text="Remove", font=("Arial", 12), width=30, command= book_remover)
                        remove_book_button.pack(pady=10)

                    elif lmw == "Borrow Book":
                        borrow_book_window = tk.Toplevel(admin_options_window)
                        borrow_book_window.title("Borrow Book")
                        borrow_book_window.geometry("500x500")
                        borrow_book_window.resizable(False, False)
                        borrow_book_window.configure(bg="white")
                        borrow_book_window.iconphoto(True, window_icon)
                        borrow_book_label = tk.Label(borrow_book_window, text="Enter Book Name", font=("Arial", 12), bg="white")
                        borrow_book_label.pack(pady=10)
                        borrow_book_entry = tk.Entry(borrow_book_window, font=("Arial", 12), borderwidth=3)
                        borrow_book_entry.pack(pady=10)
                        borrow_student_id = tk.Label(borrow_book_window, text="Enter Student ID", font=("Arial", 12), bg="white")
                        borrow_student_id.pack(pady=10)
                        borrow_student_id_entry = tk.Entry(borrow_book_window, font=("Arial", 12), borderwidth=3)
                        borrow_student_id_entry.pack(pady=10)
                        borrow_book_button = tk.Button(borrow_book_window, text="Borrow", font=("Arial", 12), width=30, command= book_borrower)
                        borrow_book_button.pack(pady=10)
                        show_bbooks_button = tk.Button(borrow_book_window, text="Borrowed Books", font=("Arial, 12"), width=30, command=show_borrowed_books)
                        show_bbooks_button.pack(pady=10)

                    elif lmw == "Edit Book Info":
                        edit_book_window = tk.Toplevel(admin_options_window)
                        edit_book_window.title("Edit Book Info")
                        edit_book_window.geometry("500x500")
                        edit_book_window.resizable(False, False)
                        edit_book_window.configure(bg="white")
                        edit_book_window.iconphoto(True, window_icon)
                        edit_book_label = tk.Label(edit_book_window, text="Enter Book Name", font=("Arial", 12), bg="white")
                        edit_book_label.pack(pady=10)
                        edit_book_entry = tk.Entry(edit_book_window, font=("Arial", 12), borderwidth=3)
                        edit_book_entry.pack(pady=10)
                        edit_author_label = tk.Label(edit_book_window, text="Enter New Author Name", font=("Arial", 12),bg="white")
                        edit_author_label.pack(pady=10)
                        edit_book_entry1 = tk.Entry(edit_book_window, font=("Arial", 12), borderwidth=3)
                        edit_book_entry1.pack(pady=10)
                        edit_book_label = tk.Label(edit_book_window, text="Enter New Edition", font=("Arial", 12),bg="white")
                        edit_book_label.pack(pady=10)
                        edit_book_entry2 = tk.Entry(edit_book_window, font=("Arial", 12), borderwidth=3)
                        edit_book_entry2.pack(pady=10)
                        edit_book_label = tk.Label(edit_book_window, text="Enter New Location", font=("Arial", 12),bg="white")
                        edit_book_label.pack(pady=10)
                        edit_book_entry3 = tk.Entry(edit_book_window, font=("Arial", 12), borderwidth=3)
                        edit_book_entry3.pack(pady=10)
                        edit_book_button = tk.Button(edit_book_window, text="Edit", font=("Arial", 12), width=30, command=book_editor)
                        edit_book_button.pack(pady=10)
                        show_all_books_button = tk.Button(edit_book_window, text="Show All Books", font=("Arial, 12"), width=30, command=show_all_books)
                        show_all_books_button.pack(pady=10)

                    elif lmw == "Return Book":
                        return_book_window = tk.Toplevel(admin_options_window)
                        return_book_window.title("Return Book")
                        return_book_window.geometry("500x500")
                        return_book_window.resizable(False, False)
                        return_book_window.configure(bg="white")
                        return_book_window.iconphoto(True, window_icon)
                        return_book_label = tk.Label(return_book_window, text="Enter Book Name", font=("Arial", 12), bg="white")
                        return_book_label.pack(pady=10)
                        return_book_entry = tk.Entry(return_book_window, font=("Arial", 12), borderwidth=3)
                        return_book_entry.pack(pady=10)
                        return_book_button = tk.Button(return_book_window, text="Return", font=("Arial", 12), width=30, command=book_returner)
                        return_book_button.pack(pady=10)

            elif work == "Hostel Manager":
                H_works = ["Check filled rooms", "Check empty rooms", "Check info of specific room", "Cancel Allotment","Allot Room"]
                for H_work in H_works:
                    H_work_button = tk.Button(admin_options_window, text=H_work, font=("Arial", 12), width=30,command=lambda p=H_work: open_HM_options(p))
                    H_work_button.pack(pady=10)

                def open_HM_options(hmw):

                    def room_allotter():
                        room = allot_room_entry.get()
                        student = student_info_entry.get()
                        roll_no = roll_no_info_entry.get()
                        cnic_no = stu_cnic_info_entry.get()
                        if student == "" or roll_no == "" or room == "" or cnic_no == "":
                            messagebox.showerror("Error", "Please fill all the fields")
                        else:
                            if student in umslib.alloted_students:
                                messagebox.showerror("Error", f"{student} is already alloted")
                            else:
                                if room in umslib.alloted_rooms:
                                    messagebox.showerror("Error", f"{room} is already alloted")
                                else:
                                    umslib.alloted_rooms.append(room)
                                    umslib.alloted_students.append(student)
                                    umslib.st_roll_no.append(roll_no)
                                    umslib.empty_rooms.remove(room)
                                    umslib.st_cnic.append(cnic_no)
                                    messagebox.showinfo("Success", f"{room} is alloted to {student}")
                                    umslib.hostel_info_update()
                                    allot_room_window.withdraw()

                    def room_canceler():
                        rm_can = cancel_allotment_entry.get()
                        if rm_can == "":
                            messagebox.showerror("Error", "Please fill all the fields")
                        else:
                            if rm_can  in umslib.alloted_students:
                                del (umslib.st_roll_no[umslib.alloted_students.index(rm_can)])
                                del (umslib.st_cnic[umslib.alloted_students.index(rm_can)])
                                umslib.empty_rooms.append(umslib.alloted_rooms[umslib.alloted_students.index(rm_can)])
                                del (umslib.alloted_rooms[umslib.alloted_students.index(rm_can)])
                                del (umslib.alloted_students[umslib.alloted_students.index(rm_can)])
                                messagebox.showinfo("Success", f"Allotment of {rm_can} is canceled")
                                umslib.hostel_info_update()
                                cancel_allotment_window.withdraw()
                            else:
                                messagebox.showerror("Error", f"Student {rm_can} is not alloted")

                    def room_checker():
                        room = room_info_entry.get()
                        if room == "":
                            messagebox.showerror("Error", "Please fill all the fields")
                        else:
                            if room in umslib.alloted_rooms:
                                messagebox.showinfo("Room Info", f"Room: {room}\nStudent: {umslib.alloted_students[umslib.alloted_rooms.index(room)]}\nRoll no: {umslib.st_roll_no[umslib.alloted_rooms.index(room)]}")
                                room_info_window.withdraw()
                            else:
                                messagebox.showinfo("Room Info", f"{room} is empty")
                                room_info_window.withdraw()

                    def empty_rooms_checker():
                        eroom = "\n".join(f"Room: {umslib.empty_rooms[i]}\n" for i in range(len(umslib.empty_rooms)))
                        messagebox.showinfo("Empty Rooms", eroom)

                    if hmw == "Check filled rooms":
                        filledrooms = "\n".join(f"Room: {umslib.alloted_rooms[i]}\nStudent: {umslib.alloted_students[i]}\nRoll no:{umslib.st_roll_no[i]}\n" for i in range(len(umslib.alloted_students)))
                        messagebox.showinfo("Filled Rooms", filledrooms)

                    elif hmw == "Check empty rooms":
                        eroom = "\n".join(f"Room: {umslib.empty_rooms[i]}\n" for i in range(len(umslib.empty_rooms)))
                        messagebox.showinfo("Empty Rooms", eroom)

                    elif hmw == "Check info of specific room":
                        room_info_window = tk.Toplevel(admin_options_window)
                        room_info_window.title("Room Info")
                        room_info_window.geometry("500x500")
                        room_info_window.resizable(False, False)
                        room_info_window.configure(bg="white")
                        room_info_window.iconphoto(True, window_icon)
                        room_info_label = tk.Label(room_info_window, text="Enter Room Number", font=("Arial", 12), bg="white")
                        room_info_label.pack(pady=10)
                        room_info_entry = tk.Entry(room_info_window, font=("Arial", 12), borderwidth=3)
                        room_info_entry.pack(pady=10)
                        room_info_button = tk.Button(room_info_window, text="Check", font=("Arial", 12), width=30, command=room_checker)
                        room_info_button.pack(pady=10)

                    elif hmw == "Cancel Allotment":
                        cancel_allotment_window = tk.Toplevel(admin_options_window)
                        cancel_allotment_window.title("Cancel Allotment")
                        cancel_allotment_window.geometry("500x500")
                        cancel_allotment_window.resizable(False, False)
                        cancel_allotment_window.configure(bg="white")
                        cancel_allotment_window.iconphoto(True, window_icon)
                        cancel_allotment_label = tk.Label(cancel_allotment_window, text="Enter Student Name", font=("Arial", 12), bg="white")
                        cancel_allotment_label.pack(pady=10)
                        cancel_allotment_entry = tk.Entry(cancel_allotment_window, font=("Arial", 12), borderwidth=3)
                        cancel_allotment_entry.pack(pady=10)
                        cancel_allotment_button = tk.Button(cancel_allotment_window, text="Cancel", font=("Arial", 12), width=30, command=room_canceler)
                        cancel_allotment_button.pack(pady=10)

                    elif hmw == "Allot Room":
                        allot_room_window = tk.Toplevel(admin_options_window)
                        allot_room_window.title("Allot Room")
                        allot_room_window.geometry("500x500")
                        allot_room_window.resizable(False, False)
                        allot_room_window.configure(bg="white")
                        allot_room_window.iconphoto(True, window_icon)
                        allot_room_label = tk.Label(allot_room_window, text="Enter Room Number", font=("Arial", 12), bg="white")
                        allot_room_label.pack(pady=10)
                        allot_room_entry = tk.Entry(allot_room_window, font=("Arial", 12), borderwidth=3)
                        allot_room_entry.pack(pady=10)
                        student_info_label = tk.Label(allot_room_window, text="Enter Student Name", font=("Arial", 12), bg="white")
                        student_info_label.pack(pady=10)
                        student_info_entry = tk.Entry(allot_room_window, font=("Arial", 12), borderwidth=3)
                        student_info_entry.pack(pady=10)
                        roll_no_info_label = tk.Label(allot_room_window, text="Enter Student Roll No", font=("Arial", 12), bg="white")
                        roll_no_info_label.pack(pady=10)
                        roll_no_info_entry = tk.Entry(allot_room_window, font=("Arial", 12), borderwidth=3)
                        roll_no_info_entry.pack(pady=10)
                        stu_cnic_info_label = tk.Label(allot_room_window, text="Enter Student CNIC", font=("Arial", 12), bg="white")
                        stu_cnic_info_label.pack(pady=10)
                        stu_cnic_info_entry = tk.Entry(allot_room_window, font=("Arial", 12), borderwidth=3)
                        stu_cnic_info_entry.pack(pady=10)
                        allot_room_button = tk.Button(allot_room_window, text="Allot", font=("Arial", 12), width=30, command=room_allotter)
                        allot_room_button.pack(pady=10)
                        available_rooms_label = tk.Button(allot_room_window, text="Available Rooms", font=("Arial", 12), bg="white",command=empty_rooms_checker)
                        available_rooms_label.pack(pady=10)

                    else:
                        messagebox.showerror("Error", "something went wrong")

            elif work == "Departmental Manager":
                D_message = tk.Message(admin_options_window, text="Welcome Departmental Manager\nWhat you want to do?", width=200, font=("Arial", 12), fg="Royal Blue")
                D_message.pack()
                D_works = ["Manage Students", "Manage Teachers", "Manage course"]
                for D_work in D_works:
                    D_work_button = tk.Button(admin_options_window, text=D_work, font=("Arial", 12), width=30,  command=lambda p=D_work: open_DM_options(p))
                    D_work_button.pack(pady=10)

                def open_DM_options(dmw):
                    admin_options_window.withdraw()
                    DM_options_window = tk.Toplevel(admin_options_window)
                    DM_options_window.maxsize(width=1500, height=1000)
                    DM_options_window.minsize(width=1000, height=300)
                    DM_options_window.title(f"{dmw}")
                    if dmw == "Manage Students":
                        sD_message = tk.Message(DM_options_window, text="Hi! Student Manager.\nWhat you want to do?", width=200, font=("Arial", 12), fg="Royal Blue", pady=10)
                        sD_message.pack()
                        sD_works = ["Display All students", "Display specific student", "Change student roll no", "Remove a student"]
                        for sD_work in sD_works:
                            sD_work_button = tk.Button(DM_options_window, text=sD_work, font=("Arial", 12), width=30, command=lambda p=sD_work: open_sDM_options(p))
                            sD_work_button.pack(pady=10)

                        def open_sDM_options(sdmw):
                            DM_options_window.withdraw()
                            sDM_options_window = tk.Toplevel(DM_options_window)
                            sDM_options_window.maxsize(width=1500, height=1000)
                            sDM_options_window.minsize(width=1000, height=300)
                            sDM_options_window.title(f"{sdmw}")

                            if sdmw == "Display All students":
                                s_dep = ["Computer Engineering", "Electrical Engineering", "Mathematics"]
                                for dep in s_dep:
                                    dep_button = tk.Button(sDM_options_window, text=dep, font=("Arial", 12), width=30, command=lambda p=dep: dep_options(p))
                                    dep_button.pack(pady=10)

                                def dep_options(ddd):
                                    sDM_options_window.withdraw()
                                    dep_options_window = tk.Toplevel(sDM_options_window)
                                    dep_options_window.maxsize(width=1500, height=1000)
                                    dep_options_window.minsize(width=1000, height=300)
                                    dep_options_window.title(f"{ddd}")

                                    if ddd == "Computer Engineering":
                                        for ce_data in range(len(umslib.stu_name_ce)):
                                            D_message = tk.Message(dep_options_window,text=f"Student no {ce_data + 1}\n Name = {umslib.stu_name_ce[ce_data]}\n Father name = {umslib.stu_fn_ce[ce_data]}\n Roll no = {umslib.stu_roll_ce[ce_data]}\n CNIC = {umslib.stu_CNIC_ce[ce_data]}\n Aggregate = {umslib.stu_aggregate_ce[ce_data]}\n Status = {umslib.stu_status_ce[ce_data]}\n", width=0, font=("Arial", 12), fg="Black")
                                            D_message.pack(anchor="w", padx=10, pady=10)
                                            D_message.pack()
                                    elif ddd == "Electrical Engineering":
                                        for ee_data in range(len(umslib.stu_name_ee)):
                                            D_message = tk.Message(dep_options_window, text=f"Student no {ee_data + 1}\n Name = {umslib.stu_name_ee[ee_data]}\n Father name = {umslib.stu_fn_ee[ee_data]}\n Roll no = {umslib.stu_roll_ee[ee_data]}\n CNIC = {umslib.stu_CNIC_ee[ee_data]}\n Aggregate = {umslib.stu_aggregate_ee[ee_data]}\n Status = {umslib.stu_status_ee[ee_data]}\n", width=0, font=("Arial", 12), fg="Black")
                                            D_message.pack(anchor="w", padx=10, pady=10)
                                            D_message.pack()
                                    elif ddd == "Mathematics":
                                        for mth_data in range(len(umslib.stu_name_mth)):
                                            D_message = tk.Message(dep_options_window, text=f"Student no {mth_data + 1}\n Name = {umslib.stu_name_mth[mth_data]}\n Father name = {umslib.stu_fn_mth[mth_data]}\n Roll no = {umslib.stu_roll_mth[mth_data]}\n CNIC = {umslib.stu_CNIC_mth[mth_data]}\n Aggregate = {umslib.stu_aggregate_mth[mth_data]}\n Status = {umslib.stu_status_mth[mth_data]}\n", width=0, font=("Arial", 12), fg="Black")
                                            D_message.pack(anchor="w", padx=10, pady=10)
                                            D_message.pack()
                                    else:
                                        messagebox.showerror("sDM_options_window", "Department not found")

                            elif sdmw == "Display specific student":

                                def func():
                                    getter = name_enter.get()
                                    umslib.CE_profile_displayer(getter)
                                    umslib.EE_profile_displayer(getter)
                                    umslib.MTH_profile_displayer(getter)

                                name_enter = Entry(sDM_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                Label(sDM_options_window, text="Enter Student Roll no:", width=20).pack()
                                name_enter.pack()
                                enter_button = tk.Button(sDM_options_window, text="Enter", font=("Arial", 12), width=30, command=func)
                                enter_button.pack()

                            elif sdmw == "Change student roll no":

                                def set_roll_ce(rollno):
                                    cde = umslib.stu_name_ce.index(name_enter.get())
                                    umslib.stu_roll_ce[cde] = rollno
                                    umslib.change_CE("sDM_options_window")
                                    sDM_options_window.withdraw()

                                def set_roll_ee(rollno):
                                    cde = umslib.stu_name_ee.index(name_enter.get())
                                    umslib.stu_roll_ee[cde] = rollno
                                    umslib.change_ee("sDM_options_window")
                                    sDM_options_window.withdraw()

                                def set_roll_mth(rollno):
                                    cde = umslib.stu_name_mth.index(name_enter.get())
                                    umslib.stu_roll_mth[cde] = rollno
                                    umslib.change_mth("sDM_options_window")
                                    sDM_options_window.withdraw()

                                def roll():
                                    if name_enter.get() in umslib.stu_name_ce:
                                        Label(sDM_options_window, text="Enter new roll no:", width=20).pack()
                                        rollno_enter = Entry(sDM_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                        rollno_enter.pack()
                                        enter_button = tk.Button(sDM_options_window, text="Enter", font=("Arial", 12), width=30, command=lambda: set_roll_ce(rollno_enter.get()))
                                        enter_button.pack()
                                    elif name_enter.get() in umslib.stu_name_ee:
                                        Label(sDM_options_window, text="Enter new roll no:", width=20).pack()
                                        rollno_enter = Entry(sDM_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                        rollno_enter.pack()
                                        enter_button = tk.Button(sDM_options_window, text="Enter", font=("Arial", 12), width=30, command=lambda: set_roll_ee(rollno_enter.get()))
                                        enter_button.pack()
                                    elif name_enter.get() in umslib.stu_name_mth:
                                        Label(sDM_options_window, text="Enter new roll no:", width=20).pack()
                                        rollno_enter = Entry(sDM_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                        rollno_enter.pack()
                                        enter_button = tk.Button(sDM_options_window, text="Enter", font=("Arial", 12), width=30,command=lambda: set_roll_mth(rollno_enter.get()))
                                        enter_button.pack()
                                    else:
                                        messagebox.showerror("Error", "Student not found")

                                Label(sDM_options_window, text="Enter the name of student:", width=20).pack()
                                name_enter = Entry(sDM_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                name_enter.pack()
                                enter_button = tk.Button(sDM_options_window, text="Enter", font=("Arial", 12), width=30, command=roll)
                                enter_button.pack()

                            elif sdmw == "Remove a student":

                                def removal():
                                    if name_enter.get() in umslib.stu_name_ce:
                                        dvd = umslib.stu_name_ce.index(name_enter.get())
                                        umslib.stu_name_ce.pop(dvd)
                                        umslib.stu_roll_ce.pop(dvd)
                                        umslib.stu_fn_ce.pop(dvd)
                                        umslib.stu_aggregate_ce.pop(dvd)
                                        umslib.stu_status_ce.pop(dvd)
                                        umslib.stu_CNIC_ce.pop(dvd)
                                        umslib.change_CE("sDM_options_window")
                                        messagebox.showinfo("sDM_options_window", f"{name_enter.get()} has been removed")

                                    elif name_enter.get() in umslib.stu_name_ee:
                                        dvd = umslib.stu_name_ee.index(name_enter.get())
                                        umslib.stu_name_ee.pop(dvd)
                                        umslib.stu_roll_ee.pop(dvd)
                                        umslib.stu_fn_ee.pop(dvd)
                                        umslib.stu_aggregate_ee.pop(dvd)
                                        umslib.stu_status_ee.pop(dvd)
                                        umslib.stu_CNIC_ee.pop(dvd)
                                        umslib.change_ee("sDM_options_window")
                                        messagebox.showinfo("sDM_options_window", f"{name_enter.get()} has been removed")

                                    elif name_enter in umslib.stu_name_mth:
                                        dvd = umslib.stu_name_mth.index(name_enter.get())
                                        umslib.stu_name_mth.pop(dvd)
                                        umslib.stu_roll_mth.pop(dvd)
                                        umslib.stu_fn_mth.pop(dvd)
                                        umslib.stu_aggregate_mth.pop(dvd)
                                        umslib.stu_status_mth.pop(dvd)
                                        umslib.stu_CNIC_mth.pop(dvd)
                                        umslib.change_mth("sDM_options_window")
                                        messagebox.showinfo("sDM_options_window",f"{name_enter.get()} has been removed")

                                    else:
                                        messagebox.showerror("sDM_options_window", "Student not found")

                                Label(sDM_options_window, text="Enter Student name:", width=20).pack()
                                name_enter = Entry(sDM_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                name_enter.pack()
                                enter_button = tk.Button(sDM_options_window, text="Enter", font=("Arial", 12), width=30, command=removal)
                                enter_button.pack()
                            else:
                                messagebox.showerror("sDM_options_window", "Something went wrong")

                    elif dmw == "Manage Teachers":
                        tD_message = tk.Message(DM_options_window,text="Hi! Teacher Manager.\nWhat you want to do?", width=200,font=("Arial", 12), fg="Royal Blue", pady=10)
                        tD_message.pack()
                        tD_works = ["Display All teachers", "Display specific Teacher", "Change Teacher subject","Remove a Teacher"]
                        for tD_work in tD_works:
                            tD_work_button = tk.Button(DM_options_window, text=tD_work, font=("Arial", 12), width=30, command=lambda p=tD_work: open_TDM_options(p))
                            tD_work_button.pack(pady=10)

                        def open_TDM_options(tdmw):
                            DM_options_window.withdraw()
                            tDM_options_window = tk.Toplevel(DM_options_window)
                            tDM_options_window.maxsize(width=1500, height=1000)
                            tDM_options_window.minsize(width=1000, height=300)
                            tDM_options_window.title(f"{tdmw}")

                            if tdmw == "Display All teachers":
                                t_dep = ["Computer Engineering", "Electrical Engineering", "Mathematics"]
                                for dep in t_dep:
                                    dep_button = tk.Button(tDM_options_window, text=dep, font=("Arial", 12), width=30, command=lambda p=dep: dep_options(p))
                                    dep_button.pack(pady=10)

                                def dep_options(ddd):
                                    tDM_options_window.withdraw()
                                    dep_options_window = tk.Toplevel(tDM_options_window)
                                    dep_options_window.maxsize(width=1500, height=1000)
                                    dep_options_window.minsize(width=1000, height=300)
                                    dep_options_window.title(f"{ddd}")

                                    if ddd == "Computer Engineering":
                                        for ce_data in range(len(umslib.tec_name_ce)):
                                            t_message = tk.Message(dep_options_window, text=f"Teacher no {ce_data + 1}\n Name = {umslib.tec_name_ce[ce_data]}\n Degree = {umslib.tec_degree_ce[ce_data]}\n City = {umslib.tec_City_ce[ce_data]}\n CNIC = {umslib.tec_CNIC_ce[ce_data]}\n  Subject = {umslib.tec_sub_ce[ce_data]}\n", width=0, font=("Arial", 12), fg="Black")
                                            t_message.pack(anchor="w", padx=10, pady=10)
                                            t_message.pack()
                                    elif ddd == "Electrical Engineering":
                                        for ee_data in range(len(umslib.tec_name_ee)):
                                            t_message = tk.Message(dep_options_window,text=f"Teacher no {ee_data + 1}\n Name = {umslib.tec_name_ee[ee_data]}\n Degree = {umslib.tec_degree_ee[ee_data]}\n City = {umslib.tec_City_ee[ee_data]}\n CNIC = {umslib.tec_CNIC_ee[ee_data]}\n Subject = {umslib.tec_sub_ee[ee_data]}\n",width=0, font=("Arial", 12), fg="Black")
                                            t_message.pack(anchor="w", padx=10, pady=10)
                                            t_message.pack()
                                    elif ddd == "Mathematics":
                                        for mth_data in range(len(umslib.tec_name_mth)):
                                            t_message = tk.Message(dep_options_window,text=f"Teacher no {mth_data + 1}\n Name = {umslib.tec_name_mth[mth_data]}\n Degree = {umslib.tec_degree_mth[mth_data]}\n City = {umslib.tec_City_mth[mth_data]}\n CNIC = {umslib.tec_CNIC_mth[mth_data]}\n Subject = {umslib.tec_sub_mth[mth_data]}\n",width=0, font=("Arial", 12), fg="Black")
                                            t_message.pack(anchor="w", padx=10, pady=10)
                                            t_message.pack()
                                    else:
                                        messagebox.showerror("tDM_options_window", "Department not found")

                            elif tdmw == "Display specific Teacher":
                                def t_func():
                                    getter = name_enter.get()
                                    umslib.CE_tec_profile_displayer(getter)
                                    umslib.EE_tec_profile_displayer(getter)
                                    umslib.MTH_tec_profile_displayer(getter)

                                name_enter = Entry(tDM_options_window, width=100, borderwidth=3, fg="black",bg="white")
                                Label(tDM_options_window, text="Enter Teacher name:", width=20).pack()
                                name_enter.pack()
                                enter_button = tk.Button(tDM_options_window, text="Enter", font=("Arial", 12),width=30, command=t_func)
                                enter_button.pack()

                            elif tdmw == "Change Teacher subject":

                                def set_subt_ce(sub):
                                    cde = umslib.tec_name_ce.index(name_enter.get())
                                    umslib.tec_sub_ce[cde] = sub
                                    umslib.change_CE("tDM_options_window")
                                    umslib.change_tec_sub(name_enter.get(), sub, "tDM_options_window")

                                def set_subt_ee(sub):
                                    cde = umslib.tec_name_ee.index(name_enter.get())
                                    umslib.tec_sub_ee[cde] = sub
                                    umslib.change_ee("tDM_options_window")
                                    umslib.change_tec_sub(name_enter.get(), sub, "tDM_options_window")

                                def set_subt_mth(sub):
                                    cde = umslib.tec_name_mth.index(name_enter.get())
                                    umslib.tec_sub_mth[cde] = sub
                                    umslib.change_mth("tDM_options_window")
                                    umslib.change_tec_sub(name_enter.get(), sub, "tDM_options_window")

                                def sub():
                                    if name_enter.get() in umslib.tec_name_ce:
                                        Label(tDM_options_window, text="Enter new Subject:", width=20).pack()
                                        sub_enter = Entry(tDM_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                        sub_enter.pack()
                                        enter_button = tk.Button(tDM_options_window, text="Enter", font=("Arial", 12), width=30, command=lambda: set_subt_ce(sub_enter.get()))
                                        enter_button.pack()
                                    elif name_enter.get() in umslib.tec_name_ee:
                                        Label(tDM_options_window, text="Enter new Subject:", width=20).pack()
                                        sub_enter = Entry(tDM_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                        sub_enter.pack()
                                        enter_button = tk.Button(tDM_options_window, text="Enter", font=("Arial", 12), width=30, command=lambda: set_subt_ee(sub_enter.get()))
                                        enter_button.pack()
                                    elif name_enter.get() in umslib.tec_name_mth:
                                        Label(tDM_options_window, text="Enter new roll no:", width=20).pack()
                                        sub_enter = Entry(tDM_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                        sub_enter.pack()
                                        enter_button = tk.Button(tDM_options_window, text="Enter", font=("Arial", 12), width=30, command=lambda: set_subt_mth(sub_enter.get()))
                                        enter_button.pack()
                                    else:
                                        messagebox.showerror("Error", "Teacher not found")

                                Label(tDM_options_window, text="Enter the name of teacher:", width=20).pack()
                                name_enter = Entry(tDM_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                name_enter.pack()
                                enter_button = tk.Button(tDM_options_window, text="Enter", font=("Arial", 12),width=30, command=sub)
                                enter_button.pack()

                            elif tdmw == "Remove a Teacher":
                                def removal_t():
                                    global sub
                                    if name_enter.get() in umslib.tec_name_ce:
                                        endex = umslib.tec_name_ce.index(name_enter.get())
                                        umslib.tec_name_ce.pop(endex)
                                        umslib.tec_degree_ce.pop(endex)
                                        umslib.tec_sub_ce.pop(endex)
                                        umslib.tec_City_ce.pop(endex)
                                        umslib.tec_CNIC_ce.pop(endex)
                                        umslib.change_CE("tDM_options_window")
                                        if sub_enter in sub:
                                            aaa = sub.index(sub_enter.get())
                                            sub.pop(aaa)
                                        for ttt in range(len(umslib.tec_info)):
                                            if name_enter.get() in umslib.tec_info[ttt]:
                                                umslib.tec_info.pop(ttt)
                                                break
                                        umslib.change_tec_file()
                                        messagebox.showinfo("tDM_options_window", f"{name_enter.get()} has been removed")

                                    elif name_enter.get() in umslib.tec_name_ee:
                                        endex = umslib.tec_name_ee.index(name_enter.get())
                                        umslib.tec_name_ee.pop(endex)
                                        umslib.tec_degree_ee.pop(endex)
                                        umslib.tec_sub_ee.pop(endex)
                                        umslib.tec_City_ee.pop(endex)
                                        umslib.tec_CNIC_ee.pop(endex)
                                        umslib.change_ee("tDM_options_window")
                                        if sub_enter in sub:
                                            aaa = sub.index(sub_enter.get())
                                            sub.pop(aaa)
                                        for ttt in range(len(umslib.tec_info)):
                                            if name_enter.get() in umslib.tec_info[ttt]:
                                                umslib.tec_info.pop(ttt)
                                                break
                                        umslib.change_tec_file()
                                        messagebox.showinfo("tDM_options_window",f"{name_enter.get()} has been removed")

                                    elif name_enter in umslib.tec_name_mth:
                                        endex = umslib.tec_name_mth.index(name_enter.get())
                                        umslib.tec_name_mth.pop(endex)
                                        umslib.tec_degree_mth.pop(endex)
                                        umslib.tec_sub_mth.pop(endex)
                                        umslib.tec_City_mth.pop(endex)
                                        umslib.tec_CNIC_mth.pop(endex)
                                        umslib.change_mth("tDM_options_window")
                                        if sub_enter in sub:
                                            aaa = sub.index(sub_enter.get())
                                            sub.pop(aaa)
                                        for ttt in range(len(umslib.tec_info)):
                                            if name_enter.get() in umslib.tec_info[ttt]:
                                                umslib.tec_info.pop(ttt)
                                                break
                                        umslib.change_tec_file()
                                        messagebox.showinfo("tDM_options_window", f"{name_enter.get()} has been removed")
                                    else:
                                        messagebox.showerror("tDM_options_window", "Teacher not found")

                                Label(tDM_options_window, text="Enter teacher name:", width=20).pack()
                                name_enter = Entry(tDM_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                name_enter.pack()
                                Label(tDM_options_window, text="Enter teacher subject:", width=20).pack()
                                sub_enter = Entry(tDM_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                sub_enter.pack()
                                enter_button = tk.Button(tDM_options_window, text="Enter", font=("Arial", 12),  width=30, command=removal_t)
                                enter_button.pack()
                            else:
                                messagebox.showerror("tDM_options_window", "Something went wrong")

                    elif dmw == "Manage course":
                        cD_message = tk.Message(DM_options_window,text="Hi! Course Manager.\nWhat you want to do?", width=200,font=("Arial", 12), fg="Royal Blue", pady=10)
                        cD_message.pack()
                        cD_works = ["Add a course to compulsory course list","Exclude a course from compulsory course list"]
                        for cD_work in cD_works:
                            cD_work_button = tk.Button(DM_options_window, text=cD_work, font=("Arial", 12), width=50, command=lambda p=cD_work: open_CDM_options(p))
                            cD_work_button.pack(pady=10)

                        def open_CDM_options(cdmw):
                            DM_options_window.withdraw()
                            cDM_options_window = tk.Toplevel(DM_options_window)
                            cDM_options_window.maxsize(width=1500, height=1000)
                            cDM_options_window.minsize(width=1000, height=300)
                            cDM_options_window.title(f"{cdmw}")

                            if cdmw == "Add a course to compulsory course list":
                                c_dep = ["Computer Engineering", "Electrical Engineering", "Mathematics"]
                                for dep in c_dep:
                                    dep_button = tk.Button(cDM_options_window, text=dep, font=("Arial", 12),width=30, command=lambda p=dep: dep_options(p))
                                    dep_button.pack(pady=10)

                                def dep_options(ddd):
                                    cDM_options_window.withdraw()
                                    depc_options_window = tk.Toplevel(cDM_options_window)
                                    depc_options_window.maxsize(width=1500, height=1000)
                                    depc_options_window.minsize(width=1000, height=300)
                                    depc_options_window.title(f"{ddd}")
                                    if ddd == "Computer Engineering":
                                        umslib.add_course(ddd, depc_options_window)
                                    elif ddd == "Electrical Engineering":
                                        umslib.add_course(ddd, depc_options_window)
                                    elif ddd == "Mathematics":
                                        umslib.add_course(ddd, depc_options_window)
                                    else:
                                        messagebox.showerror("Error", "something went wrong")

                                    def new_course():
                                        if ddd == "Computer Engineering":
                                            for ii in range(len(umslib.stu_c_ce)):
                                                temp = umslib.stu_c_ce[0]
                                                umslib.stu_c_ce[ii] = temp + " " + sub_enter.get()
                                            umslib.change_CE("depc_options_window")
                                            depc_options_window.withdraw()
                                            messagebox.showinfo("depc_options_window", "Course added successfully")
                                        elif ddd == "Electrical Engineering":
                                            for ii in range(len(umslib.stu_c_ee)):
                                                temp = umslib.stu_c_ee[ii]
                                                umslib.stu_c_ee[ii] = temp + " " + sub_enter.get()
                                            umslib.change_ee("depc_options_window")
                                            depc_options_window.withdraw()
                                            messagebox.showinfo("depc_options_window", "Course added successfully")
                                        elif ddd == "Mathematics":
                                            for ii in range(len(umslib.stu_c_mth)):
                                                temp = umslib.stu_c_mth[ii]
                                                umslib.stu_c_mth[ii] = temp + " " + sub_enter.get()
                                            umslib.change_mth("depc_options_window")
                                            depc_options_window.withdraw()
                                            messagebox.showinfo("depc_options_window", "Course added successfully")

                                    Label(depc_options_window, text="Enter the new compulsory course:", width=50).pack()
                                    sub_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                    sub_enter.pack()
                                    enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12), width=30, command=new_course)
                                    enter_button.pack()

                            elif cdmw == "Exclude a course from compulsory course list":
                                c_dep = ["Computer Engineering", "Electrical Engineering", "Mathematics"]
                                for dep in c_dep:
                                    dep_button = tk.Button(cDM_options_window, text=dep, font=("Arial", 12), width=30, command=lambda p=dep: dep_options(p))
                                    dep_button.pack(pady=10)

                                def dep_options(ddd):
                                    cDM_options_window.withdraw()
                                    depc_options_window = tk.Toplevel(cDM_options_window)
                                    depc_options_window.maxsize(width=1500, height=1000)
                                    depc_options_window.minsize(width=1000, height=300)
                                    depc_options_window.title(f"{ddd}")
                                    if ddd == "Computer Engineering":
                                        umslib.add_course(ddd, depc_options_window)
                                    elif ddd == "Electrical Engineering":
                                        umslib.add_course(ddd, depc_options_window)
                                    elif ddd == "Mathematics":
                                        umslib.add_course(ddd, depc_options_window)
                                    else:
                                        messagebox.showerror("Error", "Something went wrong")
                                    def remove_course():
                                        if ddd == "Computer Engineering":
                                            s = umslib.stu_c_ce[0].strip().split()
                                            for s_course in range(len(s)):
                                                if course_enter.get() == s[s_course]:
                                                    s.pop(s_course)
                                                    break
                                            course = ""
                                            for ss in s:
                                                course = " ".join(s)
                                            for new_c in range(len(umslib.stu_c_ce)):
                                                umslib.stu_c_ce[new_c] = course
                                            umslib.change_CE("depc_options_window")
                                            messagebox.showinfo("Removed course", "Course removed successfully")

                                        elif ddd == "Electrical Engineering":
                                            s = umslib.stu_c_ee[0].strip().split()
                                            for s_course in range(len(s)):
                                                if course_enter.get() == s[s_course]:
                                                    s.pop(s_course)
                                                    break
                                            course = ""
                                            for ss in s:
                                                course = " ".join(s)
                                            for new_c in range(len(umslib.stu_c_ee)):
                                                umslib.stu_c_ee[new_c] = course
                                            umslib.change_ee("depc_options_window")
                                            messagebox.showinfo("Removed course", "Course removed successfully")

                                        elif ddd == "Mathematics":
                                            s = umslib.stu_c_mth[0].strip().split()
                                            for s_course in range(len(s)):
                                                if course_enter.get() == s[s_course]:
                                                    s.pop(s_course)
                                                    break
                                            course = ""
                                            for ss in s:
                                                course = " ".join(s)
                                            for new_c in range(len(umslib.stu_c_mth)):
                                                umslib.stu_c_mth[new_c] = course
                                            umslib.change_mth("depc_options_window")
                                            messagebox.showinfo("Removed course", "Course removed successfully")
                                        else:
                                            messagebox.showerror("Error", "something went wrong")
                                    Label(depc_options_window, text="Enter the cousre you want to remove:", width=50).pack()
                                    course_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black", bg="white")
                                    course_enter.pack()
                                    enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12),
                                                             width=30, command=remove_course)
                                    enter_button.pack()
                            else:
                                messagebox.showerror("Error", "something went wrong")
                    else:
                        messagebox.showerror("Error", "something went wrong")
            else:
                messagebox.showerror("Error", "something went wrong")

    elif profile == "Teacher":
        T_works = ["Mark attendance", "Mark GPA", "Resign", "View students", "Profile"]
        for T_work in T_works:
            T_work_button = tk.Button(profile_window, text=T_work, font=("Arial", 12), width=30,
                                      command=lambda p=T_work: open_teacher_options(p))
            T_work_button.pack(pady=10)

        def open_teacher_options(tw):
            profile_window.withdraw()
            teacher_options_window = tk.Toplevel(profile_window)
            teacher_options_window.title("Teacher Options")
            teacher_options_window.maxsize(width=1500, height=1000)
            teacher_options_window.minsize(width=700, height=300)
            teacher_options_window.title(f"{tw}")
            if tw == "Mark attendance":
                c_dep = ["Computer Engineering", "Electrical Engineering", "Mathematics"]
                for dep in c_dep:
                    dep_button = tk.Button(teacher_options_window, text=dep, font=("Arial", 12),
                                           width=30,
                                           command=lambda p=dep: dep_options(p))
                    dep_button.pack(pady=10)

                def dep_options(ddd):
                    teacher_options_window.withdraw()
                    depc_options_window = tk.Toplevel(teacher_options_window)
                    depc_options_window.maxsize(width=1500, height=1000)
                    depc_options_window.minsize(width=1000, height=300)
                    depc_options_window.title(f"{ddd}")
                    if ddd == "Computer Engineering":
                        def att_loop():
                            with open("CE Attendance.txt", "a") as CE_att_ptr:
                                if CE_att_ptr:
                                    print("CE attendance file opened successfully")
                                    attendance = attendance_entry.get()
                                    print(f"Attendance: {attendance}")
                                    CE_att_ptr.write(f"{attendance_entry.get()}\n")
                                    depc_options_window.withdraw()
                        Label(depc_options_window, text=umslib.att_ce_name, width=50).pack()
                        Label(depc_options_window, text=umslib.att_ce_roll, width=50).pack()
                        Label(depc_options_window, text="Enter the attendance:", width=50).pack()
                        attendance_entry = Entry(depc_options_window, width=70, borderwidth=3,
                                                 fg="black", bg="white")
                        attendance_entry.pack()
                        enter_button = tk.Button(depc_options_window, text="Enter",
                                                 font=("Arial", 12), width=30, command=att_loop)
                        enter_button.pack()

                    elif ddd == "Electrical Engineering":
                        def att_loop():
                            with open("EE Attendance.txt", "a") as EE_att_ptr:
                                if EE_att_ptr:
                                    print("EE attendance file opened successfully")
                                    attendance = attendance_entry.get()
                                    print(f"Attendance: {attendance}")
                                    EE_att_ptr.write(f"{attendance_entry.get()}\n")
                                    depc_options_window.withdraw()
                        Label(depc_options_window, text=umslib.att_ee_name, width=50).pack()
                        Label(depc_options_window, text=umslib.att_ee_roll, width=50).pack()
                        Label(depc_options_window, text="Enter the attendance:", width=50).pack()
                        attendance_entry = Entry(depc_options_window, width=70, borderwidth=3,
                                                 fg="black", bg="white")
                        attendance_entry.pack()
                        enter_button = tk.Button(depc_options_window, text="Enter",
                                                 font=("Arial", 12), width=30, command=att_loop)
                        enter_button.pack()

                    elif ddd == "Mathematics":
                        def att_loop():
                            with open("MTH Attendance.txt", "a") as MTH_att_ptr:
                                if MTH_att_ptr:
                                    print("MTH attendance file opened successfully")
                                    attendance = attendance_entry.get()
                                    print(f"Attendance: {attendance}")
                                    MTH_att_ptr.write(f"{attendance_entry.get()}\n")
                                    depc_options_window.withdraw()
                        Label(depc_options_window, text=umslib.att_mth_name, width=50).pack()
                        Label(depc_options_window, text=umslib.att_mth_roll, width=50).pack()
                        Label(depc_options_window, text="Enter the attendance:", width=50).pack()
                        attendance_entry = Entry(depc_options_window, width=70, borderwidth=3,
                                                 fg="black", bg="white")
                        attendance_entry.pack()
                        enter_button = tk.Button(depc_options_window, text="Enter",
                                                 font=("Arial", 12), width=30, command=att_loop)
                        enter_button.pack()
                    else:
                        messagebox.showerror("Error", "something went wrong")

            elif tw == "Mark GPA":
                c_dep = ["Computer Engineering", "Electrical Engineering", "Mathematics"]
                for dep in c_dep:
                    dep_button = tk.Button(teacher_options_window, text=dep, font=("Arial", 12),
                                           width=30,
                                           command=lambda p=dep: dep_options(p))
                    dep_button.pack(pady=10)

                def dep_options(ddd):
                    teacher_options_window.withdraw()
                    depc_options_window = tk.Toplevel(teacher_options_window)
                    depc_options_window.maxsize(width=1500, height=1000)
                    depc_options_window.minsize(width=1000, height=300)
                    depc_options_window.title(f"{ddd}")
                    if ddd == "Computer Engineering":
                        def gpa_loop():
                            with open("CE GPA.txt", "a") as CE_gpa_ptr:
                                if CE_gpa_ptr:
                                    print("CE gpa file opened successfully")
                                    CE_gpa_ptr.write(f"{sem_entry.get()}\n")
                                    gpa = gpa_entry.get()
                                    print(f"GPA: {gpa}")
                                    CE_gpa_ptr.write(f"{gpa_entry.get()}\n")
                                    depc_options_window.withdraw()
                        Label(depc_options_window, text=umslib.gpa_ce_name, width=50).pack()
                        Label(depc_options_window, text=umslib.gpa_ce_roll, width=50).pack()
                        Label(depc_options_window, text="Enter the Semester:", width=50).pack()
                        sem_entry = Entry(depc_options_window, width=70, borderwidth=3,
                                          fg="black", bg="white")
                        sem_entry.pack()
                        Label(depc_options_window, text="Enter the GPA:", width=50).pack()
                        gpa_entry = Entry(depc_options_window, width=70, borderwidth=3,
                                          fg="black", bg="white")
                        gpa_entry.pack()
                        enter_button = tk.Button(depc_options_window, text="Enter",
                                                 font=("Arial", 12), width=30, command=gpa_loop)
                        enter_button.pack()

                    elif ddd == "Electrical Engineering":
                        def gpa_loop():
                            with open("EE GPA.txt", "a") as EE_gpa_ptr:
                                if EE_gpa_ptr:
                                    print("EE gpa file opened successfully")
                                    EE_gpa_ptr.write(f"{sem_entry.get()}\n")
                                    gpa = gpa_entry.get()
                                    print(f"GPA: {gpa}")
                                    EE_gpa_ptr.write(f"{gpa_entry.get()}\n")
                                    depc_options_window.withdraw()
                        Label(depc_options_window, text=umslib.gpa_ee_name, width=50).pack()
                        Label(depc_options_window, text=umslib.gpa_ee_roll, width=50).pack()
                        Label(depc_options_window, text="Enter the Semester:", width=50).pack()
                        sem_entry = Entry(depc_options_window, width=70, borderwidth=3,
                                          fg="black", bg="white")
                        sem_entry.pack()
                        Label(depc_options_window, text="Enter the GPA:", width=50).pack()
                        gpa_entry = Entry(depc_options_window, width=70, borderwidth=3,
                                          fg="black", bg="white")
                        gpa_entry.pack()
                        enter_button = tk.Button(depc_options_window, text="Enter",
                                                 font=("Arial", 12), width=30, command=gpa_loop)
                        enter_button.pack()

                    elif ddd == "Mathematics":

                        def gpa_loop():
                            with open("MTH GPA.txt", "a") as MTH_gpa_ptr:
                                if MTH_gpa_ptr:
                                    print("MTH gpa file opened successfully")
                                    MTH_gpa_ptr.write(f"{sem_entry.get()}\n")
                                    gpa = gpa_entry.get()
                                    print(f"GPA: {gpa}")
                                    MTH_gpa_ptr.write(f"{gpa_entry.get()}\n")
                                    depc_options_window.withdraw()

                        Label(depc_options_window, text=umslib.gpa_mth_name, width=50).pack()
                        Label(depc_options_window, text=umslib.gpa_mth_roll, width=50).pack()
                        Label(depc_options_window, text="Enter the Semester:", width=50).pack()
                        sem_entry = Entry(depc_options_window, width=70, borderwidth=3,
                                              fg="black", bg="white")
                        sem_entry.pack()
                        Label(depc_options_window, text="Enter the GPA:", width=50).pack()
                        gpa_entry = Entry(depc_options_window, width=70, borderwidth=3,
                                          fg="black", bg="white")
                        gpa_entry.pack()
                        enter_button = tk.Button(depc_options_window, text="Enter",
                                                 font=("Arial", 12), width=30, command=gpa_loop)
                        enter_button.pack()
                    else:
                        messagebox.showerror("Error", "Something went wrong")

            elif tw == "Resign":

                def removal_t():
                    global sub
                    if name_enter.get() in umslib.tec_name_ce:
                        endex = umslib.tec_name_ce.index(name_enter.get())
                        umslib.tec_name_ce.pop(endex)
                        umslib.tec_degree_ce.pop(endex)
                        umslib.tec_sub_ce.pop(endex)
                        umslib.tec_City_ce.pop(endex)
                        umslib.tec_CNIC_ce.pop(endex)
                        umslib.change_CE("teacher_options_window")
                        if sub_enter in umslib.sub:
                            aaa = umslib.sub.index(sub_enter.get())
                            umslib.sub.pop(aaa)
                        for ttt in range(len(umslib.tec_info)):
                            if name_enter.get() in umslib.tec_info[ttt]:
                                umslib.tec_info.pop(ttt)
                                break
                        umslib.change_tec_file()
                        messagebox.showinfo("teacher_options_window",
                                            f"{name_enter.get()} has been removed")

                    elif name_enter.get() in umslib.tec_name_ee:
                        endex = umslib.tec_name_ee.index(name_enter.get())
                        umslib.tec_name_ee.pop(endex)
                        umslib.tec_degree_ee.pop(endex)
                        umslib.tec_sub_ee.pop(endex)
                        umslib.tec_City_ee.pop(endex)
                        umslib.tec_CNIC_ee.pop(endex)
                        umslib.change_ee("teacher_options_window")
                        if sub_enter in sub:
                            aaa = sub.index(sub_enter.get())
                            sub.pop(aaa)
                        for ttt in range(len(umslib.tec_info)):
                            if name_enter.get() in umslib.tec_info[ttt]:
                                umslib.tec_info.pop(ttt)
                                break
                        umslib.change_tec_file()
                        messagebox.showinfo("teacher_options_window",
                                            f"{name_enter.get()} has been removed")

                    elif name_enter in umslib.tec_name_mth:
                        endex = umslib.tec_name_mth.index(name_enter.get())
                        umslib.tec_name_mth.pop(endex)
                        umslib.tec_degree_mth.pop(endex)
                        umslib.tec_sub_mth.pop(endex)
                        umslib.tec_City_mth.pop(endex)
                        umslib.tec_CNIC_mth.pop(endex)
                        umslib.change_mth("teacher_options_window")
                        if sub_enter in sub:
                            aaa = sub.index(sub_enter.get())
                            sub.pop(aaa)
                        for ttt in range(len(umslib.tec_info)):
                            if name_enter.get() in umslib.tec_info[ttt]:
                                umslib.tec_info.pop(ttt)
                                break
                        umslib.change_tec_file()
                        messagebox.showinfo("teacher_options_window",
                                            f"{name_enter.get()} has been removed")

                    else:
                        messagebox.showerror("teacher_options_window", "Teacher not found")

                Label(teacher_options_window, text="Enter your name:", width=20).pack()
                name_enter = Entry(teacher_options_window, width=100, borderwidth=3, fg="black", bg="white")
                name_enter.pack()
                Label(teacher_options_window, text="Enter your subject:", width=20).pack()
                sub_enter = Entry(teacher_options_window, width=100, borderwidth=3, fg="black", bg="white")
                sub_enter.pack()
                enter_button = tk.Button(teacher_options_window, text="Enter", font=("Arial", 12),
                                         width=30, command=removal_t)
                enter_button.pack()

            elif tw == "View students":
                c_dep = ["Computer Engineering", "Electrical Engineering", "Mathematics"]
                for dep in c_dep:
                    dep_button = tk.Button(teacher_options_window, text=dep, font=("Arial", 12),
                                           width=30,
                                           command=lambda p=dep: dep_options(p))
                    dep_button.pack(pady=10)

                def dep_options(ddd):
                    teacher_options_window.withdraw()
                    depc_options_window = tk.Toplevel(teacher_options_window)
                    depc_options_window.maxsize(width=1500, height=1000)
                    depc_options_window.minsize(width=1000, height=300)
                    depc_options_window.title(f"{ddd}")

                    if ddd == "Computer Engineering":
                        for ce_data in range(len(umslib.stu_name_ce)):
                            D_message = tk.Message(depc_options_window,
                                                   text=f"Student no {ce_data + 1}\n Name = {umslib.stu_name_ce[ce_data]}\n Father name = {umslib.stu_fn_ce[ce_data]}\n Roll no = {umslib.stu_roll_ce[ce_data]}\n CNIC = {umslib.stu_CNIC_ce[ce_data]}\n Aggregate = {umslib.stu_aggregate_ce[ce_data]}\n Status = {umslib.stu_status_ce[ce_data]}\n",
                                                   width=0,
                                                   font=("Arial", 12), fg="Black")
                            D_message.pack(anchor="w", padx=10, pady=10)
                            D_message.pack()

                    elif ddd == "Electrical Engineering":
                        for ee_data in range(len(umslib.stu_name_ee)):
                            D_message = tk.Message(depc_options_window,
                                                   text=f"Student no {ee_data + 1}\n Name = {umslib.stu_name_ee[ee_data]}\n Father name = {umslib.stu_fn_ee[ee_data]}\n Roll no = {umslib.stu_roll_ee[ee_data]}\n CNIC = {umslib.stu_CNIC_ee[ee_data]}\n Aggregate = {umslib.stu_aggregate_ee[ee_data]}\n Status = {umslib.stu_status_ee[ee_data]}\n",
                                                   width=0,
                                                   font=("Arial", 12), fg="Black")
                            D_message.pack(anchor="w", padx=10, pady=10)
                            D_message.pack()

                    elif ddd == "Mathematics":
                        for mth_data in range(len(umslib.stu_name_mth)):
                            D_message = tk.Message(depc_options_window,
                                                   text=f"Student no {mth_data + 1}\n Name = {umslib.stu_name_mth[mth_data]}\n Father name = {umslib.stu_fn_mth[mth_data]}\n Roll no = {umslib.stu_roll_mth[mth_data]}\n CNIC = {umslib.stu_CNIC_mth[mth_data]}\n Aggregate = {umslib.stu_aggregate_mth[mth_data]}\n Status = {umslib.stu_status_mth[mth_data]}\n",
                                                   width=0,
                                                   font=("Arial", 12), fg="Black")
                            D_message.pack(anchor="w", padx=10, pady=10)
                            D_message.pack()
                    else:
                        messagebox.showerror("Error", "Something went wrong")

            elif tw == "Profile":
                c_dep = ["Computer Engineering", "Electrical Engineering", "Mathematics"]
                for dep in c_dep:
                    dep_button = tk.Button(teacher_options_window, text=dep, font=("Arial", 12),
                                           width=30,
                                           command=lambda p=dep: dep_options(p))
                    dep_button.pack(pady=10)

                def dep_options(ddd):
                    teacher_options_window.withdraw()
                    depc_options_window = tk.Toplevel(teacher_options_window)
                    depc_options_window.maxsize(width=1500, height=1000)
                    depc_options_window.minsize(width=1000, height=300)
                    depc_options_window.title(f"{ddd}")
                    if ddd == "Computer Engineering":

                        def upate_tprofile(d, c, cn):
                            l = umslib.tec_name_ce.index(name_enter.get())
                            umslib.tec_degree_ce[l] = d
                            umslib.tec_City_ce[l] = c
                            umslib.tec_CNIC_ce[l] = cn
                            umslib.CE_tec_profile_displayer(name_enter.get())
                            depc_options_window.withdraw()

                        def edit_profile_e():
                            Label(depc_options_window, text="Enter your new degree:", width=20).pack()
                            c_degree_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",

                                                   bg="white")
                            c_degree_enter.pack()
                            Label(depc_options_window, text="Enter your current city:", width=20).pack()
                            c_city_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black", bg="white")
                            c_city_enter.pack()
                            Label(depc_options_window, text="Enter your CNIC:", width=20).pack()
                            c_cnic_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black", bg="white")
                            c_cnic_enter.pack()
                            enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12),
                                                     width=30, command=lambda: upate_tprofile(c_degree_enter.get(),
                                                                                              c_city_enter.get(),
                                                                                              c_cnic_enter.get()))
                            enter_button.pack()

                        def quit():
                            depc_options_window.withdraw()

                        def t_display_ce():
                            umslib.CE_tec_profile_displayer(name_enter.get())
                        Label(depc_options_window, text="Enter your name:", width=20).pack()
                        name_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black", bg="white")
                        name_enter.pack()
                        enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12),
                                                 width=30, command=t_display_ce)
                        enter_button.pack()
                        Label(depc_options_window, text="Do you want to edit your profile:", width=40).pack()
                        yes_button = tk.Button(depc_options_window, text="YES", font=("Arial", 12),
                                               width=30, command=edit_profile_e)
                        yes_button.pack()
                        no_button = tk.Button(depc_options_window, text="NO", font=("Arial", 12),
                                              width=30, command=quit)
                        no_button.pack()

                    elif ddd == "Electrical Engineering":

                        def upate_tprofile(d, c, cn):
                            l = umslib.tec_name_ee.index(name_enter.get())
                            umslib.tec_degree_ee[l] = d
                            umslib.tec_City_ee[l] = c
                            umslib.tec_CNIC_ee[l] = cn
                            umslib.EE_tec_profile_displayer(name_enter.get())
                            depc_options_window.withdraw()

                        def edit_profile_e():
                            Label(depc_options_window, text="Enter your new degree:", width=20).pack()
                            e_degree_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                                   bg="white")
                            e_degree_enter.pack()
                            Label(depc_options_window, text="Enter your current city:", width=20).pack()
                            e_city_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black", bg="white")
                            e_city_enter.pack()
                            Label(depc_options_window, text="Enter your CNIC:", width=20).pack()
                            e_cnic_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black", bg="white")
                            e_cnic_enter.pack()
                            enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12),
                                                     width=30, command=lambda: upate_tprofile(e_degree_enter.get(),
                                                                                              e_city_enter.get(),
                                                                                              e_cnic_enter.get()))
                            enter_button.pack()

                        def quit():
                            depc_options_window.withdraw()

                        def t_display_ee():
                            umslib.EE_tec_profile_displayer(name_enter.get())
                        Label(depc_options_window, text="Enter your name:", width=20).pack()
                        name_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black", bg="white")
                        name_enter.pack()
                        enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12),
                                                 width=30, command=t_display_ee)
                        enter_button.pack()
                        Label(depc_options_window, text="Do you want to edit your profile:", width=40).pack()
                        yes_button = tk.Button(depc_options_window, text="YES", font=("Arial", 12),
                                               width=30, command=edit_profile_e)
                        yes_button.pack()
                        no_button = tk.Button(depc_options_window, text="NO", font=("Arial", 12),
                                              width=30, command=quit)
                        no_button.pack()

                    elif ddd == "Mathematics":

                        def upate_tprofile(d, c, cn):
                            l = umslib.tec_name_mth.index(name_enter.get())
                            umslib.tec_degree_mth[l] = d
                            umslib.tec_City_mth[l] = c
                            umslib.tec_CNIC_mth[l] = cn
                            umslib.MTH_tec_profile_displayer(name_enter.get())
                            depc_options_window.withdraw()

                        def edit_profile_m():
                            Label(depc_options_window, text="Enter your new degree:", width=20).pack()
                            n_degree_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                                   bg="white")
                            n_degree_enter.pack()
                            Label(depc_options_window, text="Enter your current city:", width=20).pack()
                            n_city_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black", bg="white")
                            n_city_enter.pack()
                            Label(depc_options_window, text="Enter your CNIC:", width=20).pack()
                            n_cnic_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black", bg="white")
                            n_cnic_enter.pack()
                            enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12),
                                                     width=30, command=lambda: upate_tprofile(n_degree_enter.get(),
                                                                                              n_city_enter.get(),
                                                                                              n_cnic_enter.get()))
                            enter_button.pack()

                        def quit():
                            depc_options_window.withdraw()

                        def t_display_mth():
                            umslib.MTH_tec_profile_displayer(name_enter.get())
                        Label(depc_options_window, text="Enter your name:", width=20).pack()
                        name_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black", bg="white")
                        name_enter.pack()
                        enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12),
                                                 width=30, command=t_display_mth)
                        enter_button.pack()
                        Label(depc_options_window, text="Do you want to edit your profile:", width=40).pack()
                        yes_button = tk.Button(depc_options_window, text="YES", font=("Arial", 12),
                                               width=30, command=edit_profile_m)
                        yes_button.pack()
                        no_button = tk.Button(depc_options_window, text="NO", font=("Arial", 12),
                                              width=30, command=quit)
                        no_button.pack()

                    else:
                        messagebox.showerror("Error", "Something went wrong")
            else:
                messagebox.showerror("teacher_options_window", "Something went wrong")

    elif profile == "Student":
        stu_options = ["View profile", "View GPA", "View courses", "Take a course", "Print Challan"]
        for stu_option in stu_options:
            stu_button = tk.Button(profile_window, text=stu_option, font=("Arial", 12), width=30,
                                   command=lambda p=stu_option: open_student_options(p))
            stu_button.pack(pady=10)

        def open_student_options(a):
            student_options_window = tk.Toplevel(profile_window)
            student_options_window.title(f"{a}")
            student_options_window.maxsize(width=1500, height=1000)
            student_options_window.minsize(width=700, height=300)

            def courses():
                courses = ["Pak Studies", "Quran Translation", "International Language"]
                for cor in courses:
                    cor_button = tk.Button(student_options_window, text=cor, font=("Arial", 12),
                                           width=30,
                                           command=lambda p=cor: course_options(p))
                    cor_button.pack(pady=10)

                def course_options(p):
                    if stu_entry2.get() == "Computer Engineering":
                        f = umslib.stu_roll_ce.index(stu_entry.get())
                        new_courses = umslib.stu_c_ce[f] + " " + p
                        umslib.stu_c_ce[f] = new_courses
                        umslib.change_CE("student_options_window")
                        student_options_window.withdraw()
                    elif stu_entry2.get() == "Electrical Engineering":
                        f = umslib.stu_roll_ee.index(stu_entry.get())
                        new_courses = umslib.stu_c_ee[f] + " " + p
                        umslib.stu_c_ee[f] = new_courses
                        umslib.change_ee("student_options_window")
                        student_options_window.withdraw()
                    elif stu_entry2.get() == "Mathematics":
                        f = umslib.stu_roll_mth.index(stu_entry.get())
                        new_courses = umslib.stu_c_mth[f] + " " + p
                        umslib.stu_c_mth[f] = new_courses
                        umslib.change_mth("student_options_window")
                        student_options_window.withdraw()
                    else:
                        messagebox.showerror("Error", "something went wrong")

            def gpa_viewer():
                entry = gpa_entry.get()
                umslib.gpa_displayer(entry)

            def challan_viewer():
                entry = challan_entry.get()
                if entry in umslib.stu_roll_ce:
                    indx = umslib.stu_roll_ce.index(entry)
                    if umslib.stu_status_ce[indx] == "Hostelite":
                        umslib.CE_challan_agg_H(indx)
                    else:
                        umslib.CE_challan_agg(indx)

                elif entry in umslib.stu_roll_ee:
                    indx = umslib.stu_roll_ee.index(entry)
                    if umslib.stu_status_ee[indx] == "Hostelite":
                        umslib.EE_challan_agg_H(indx)
                    else:
                        umslib.EE_challan_agg(indx)

                elif entry in umslib.stu_roll_mth:
                    indx = umslib.stu_roll_mth.index(entry)
                    if umslib.stu_status_mth[indx] == "Hostelite":
                        umslib.MTH_challan_agg_H(indx)
                    else:
                        umslib.MTH_challan_agg(indx)
                else:
                    messagebox.showerror("student_options_window", "Student not found")

            if a == "View profile":
                c_dep = ["Computer Engineering", "Electrical Engineering", "Mathematics"]

                for dep in c_dep:
                    dep_button = tk.Button(student_options_window, text=dep, font=("Arial", 12),
                                           width=30,
                                           command=lambda p=dep: dep_options(p))
                    dep_button.pack(pady=10)

                def dep_options(ddd):
                    student_options_window.withdraw()
                    depc_options_window = tk.Toplevel(student_options_window)
                    depc_options_window.maxsize(width=1500, height=1000)
                    depc_options_window.minsize(width=1000, height=300)
                    depc_options_window.title(f"{ddd}")

                    if ddd == "Computer Engineering":

                        def upate_sprofile(n, f, cn):
                            l = umslib.stu_roll_ce.index(roll_enter.get())
                            umslib.stu_name_ce[l] = n
                            umslib.stu_fn_ce[l] = f
                            umslib.stu_CNIC_ce[l] = cn
                            umslib.CE_profile_displayer(roll_enter.get())
                            depc_options_window.withdraw()

                        def edit_profile_ce():
                            Label(depc_options_window, text="Enter your name:", width=20).pack()
                            c_name_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                                 bg="white")
                            c_name_enter.pack()
                            Label(depc_options_window, text="Enter your current cnic:", width=20).pack()
                            c_cnic_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                                 bg="white")
                            c_cnic_enter.pack()
                            Label(depc_options_window, text="Enter your father name:", width=20).pack()
                            c_fn_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                               bg="white")
                            c_fn_enter.pack()
                            enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12),
                                                     width=30,
                                                     command=lambda: upate_sprofile(c_name_enter.get(),
                                                                                    c_fn_enter.get(),
                                                                                    c_cnic_enter.get()))
                            enter_button.pack()

                        def quit():
                            depc_options_window.withdraw()

                        def s_display_ce():
                            umslib.CE_profile_displayer(roll_enter.get())

                        Label(depc_options_window, text="Enter your roll no:", width=20).pack()
                        roll_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                           bg="white")
                        roll_enter.pack()
                        enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12),
                                                 width=30, command=s_display_ce)
                        enter_button.pack()
                        Label(depc_options_window, text="Do you want to edit your profile:", width=40).pack()
                        yes_button = tk.Button(depc_options_window, text="YES", font=("Arial", 12),
                                               width=30, command=edit_profile_ce)
                        yes_button.pack()
                        no_button = tk.Button(depc_options_window, text="NO", font=("Arial", 12),
                                              width=30, command=quit)
                        no_button.pack()

                    elif ddd == "Electrical Engineering":

                        def update_sprofile(n, f, cn):
                            l = umslib.stu_roll_ee.index(roll_enter.get())
                            umslib.stu_name_ee[l] = n
                            umslib.stu_fn_ee[l] = f
                            umslib.stu_CNIC_ee[l] = cn
                            umslib.EE_profile_displayer(roll_enter.get())
                            depc_options_window.withdraw()

                        def edit_profile_ee():
                            Label(depc_options_window, text="Enter your name:", width=20).pack()
                            c_name_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                                 bg="white")
                            c_name_enter.pack()
                            Label(depc_options_window, text="Enter your current cnic:", width=20).pack()
                            c_cnic_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                                 bg="white")
                            c_cnic_enter.pack()
                            Label(depc_options_window, text="Enter your father name:", width=20).pack()
                            c_fn_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                               bg="white")
                            c_fn_enter.pack()
                            enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12),
                                                     width=30,
                                                     command=lambda: update_sprofile(c_name_enter.get(),
                                                                                     c_fn_enter.get(),
                                                                                     c_cnic_enter.get()))
                            enter_button.pack()

                        def quit():
                            depc_options_window.withdraw()

                        def s_display_ee():
                            umslib.EE_profile_displayer(roll_enter.get())

                        Label(depc_options_window, text="Enter your roll no:", width=20).pack()
                        roll_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                           bg="white")
                        roll_enter.pack()
                        enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12),
                                                 width=30, command=s_display_ee)
                        enter_button.pack()
                        Label(depc_options_window, text="Do you want to edit your profile:", width=40).pack()
                        yes_button = tk.Button(depc_options_window, text="YES", font=("Arial", 12),
                                               width=30, command=edit_profile_ee)
                        yes_button.pack()
                        no_button = tk.Button(depc_options_window, text="NO", font=("Arial", 12),
                                              width=30, command=quit)
                        no_button.pack()

                    elif ddd == "Mathematics":

                        def update_sprofile(n, f, cn):
                            l = umslib.stu_roll_mth.index(roll_enter.get())
                            umslib.stu_name_mth[l] = n
                            umslib.stu_fn_mth[l] = f
                            umslib.stu_CNIC_mth[l] = cn
                            umslib.MTH_profile_displayer(roll_enter.get())
                            depc_options_window.withdraw()

                        def edit_profile_mth():
                            Label(depc_options_window, text="Enter your name:", width=20).pack()
                            c_name_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                                 bg="white")
                            c_name_enter.pack()
                            Label(depc_options_window, text="Enter your current cnic:", width=20).pack()
                            c_cnic_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                                 bg="white")
                            c_cnic_enter.pack()
                            Label(depc_options_window, text="Enter your father name:", width=20).pack()
                            c_fn_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                               bg="white")
                            c_fn_enter.pack()
                            enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12),
                                                     width=30,
                                                     command=lambda: update_sprofile(c_name_enter.get(),
                                                                                     c_fn_enter.get(),
                                                                                     c_cnic_enter.get()))
                            enter_button.pack()

                        def quit():
                            depc_options_window.withdraw()

                        def s_display_mth():
                            umslib.MTH_profile_displayer(roll_enter.get())

                        Label(depc_options_window, text="Enter your roll no:", width=20).pack()
                        roll_enter = Entry(depc_options_window, width=100, borderwidth=3, fg="black",
                                           bg="white")
                        roll_enter.pack()
                        enter_button = tk.Button(depc_options_window, text="Enter", font=("Arial", 12),
                                                 width=30, command=s_display_mth)
                        enter_button.pack()
                        Label(depc_options_window, text="Do you want to edit your profile:", width=40).pack()
                        yes_button = tk.Button(depc_options_window, text="YES", font=("Arial", 12),
                                               width=30, command=edit_profile_mth)
                        yes_button.pack()
                        no_button = tk.Button(depc_options_window, text="NO", font=("Arial", 12),
                                              width=30, command=quit)
                        no_button.pack()
                    else:
                        messagebox.showerror("Error", "Something went wrong")

            elif a == "View GPA":
                gpa_message = Label(student_options_window, text="Enter Roll no:", width=20)
                gpa_message.pack()
                gpa_entry = Entry(student_options_window, width=100, borderwidth=3, fg="black", bg="white")
                gpa_entry.pack()
                gpa_bt = tk.Button(student_options_window, text="Enter", font=("Arial", 12), width=30,
                                   command=gpa_viewer)
                gpa_bt.pack()

            elif a == "View attendance":
                att_message = Label(student_options_window, text="Enter Roll no:", width=20)
                att_message.pack()
                att_entry = Entry(student_options_window, width=100, borderwidth=3, fg="black", bg="white")
                att_entry.pack()
                att_bt = tk.Button(student_options_window, text="Enter", font=("Arial", 12), width=30)
                att_bt.pack()

            elif a == "View courses":
                def withdraw():
                    student_options_window.withdraw()

                course_message = Label(student_options_window, text="Enter Department", width=20)
                course_message.pack()
                course_entry = Entry(student_options_window, width=100, borderwidth=3, fg="black", bg="white")
                course_entry.pack()
                course_bt = tk.Button(student_options_window, text="Enter", font=("Arial", 12), width=30,
                                      command=lambda: umslib.add_course(course_entry.get(),
                                                                        student_options_window))
                course_bt.pack()
                course_ok = tk.Button(student_options_window, text="ok", font=("Arial", 12), width=30,
                                      command=withdraw)
                course_ok.pack()

            elif a == "Take a course":
                stu_label = tk.Label(student_options_window, text="Enter your roll no:", width=20)
                stu_label.pack()
                stu_entry = tk.Entry(student_options_window, width=100, borderwidth=3, fg="black", bg="white")
                stu_entry.pack()
                stu_label2 = tk.Label(student_options_window, text="Enter Department Name:", width=20)
                stu_label2.pack()
                stu_entry2 = tk.Entry(student_options_window, width=100, borderwidth=3, fg="black", bg="white")
                stu_entry2.pack()
                stu_button = tk.Button(student_options_window, text="Enter", font=("Arial", 12), width=30,
                                       command=courses)
                stu_button.pack()

            elif a == "Print Challan":
                challan_message = Label(student_options_window, text="Enter Roll no:", width=20)
                challan_message.pack()
                challan_entry = Entry(student_options_window, width=100, borderwidth=3, fg="black", bg="white")
                challan_entry.pack()
                challan_bt = tk.Button(student_options_window, text="Enter", font=("Arial", 12), width=30,
                                       command=challan_viewer)
                challan_bt.pack()
            else:
                messagebox.showerror("Error", "something went wrong")

    elif profile == "Quit":
        print("Quit selected")
        window.quit()
    else:
        messagebox.showerror("Error", "something went wrong")

frame = tk.Frame(window)
frame.pack(anchor="center",pady=150)
profiles = ["Admin", "Teacher", "Student", "Quit"]
for profile in profiles:
    profile_button = tk.Button(window, text=profile, font=("Arial", 12), width=30, command=lambda p=profile: open_profile(p))
    profile_button.pack(pady=10)

# Run the main event loop
window.mainloop()